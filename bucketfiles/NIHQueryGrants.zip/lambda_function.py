from opensearchpy import OpenSearch, RequestsHttpConnection, AWSV4SignerAuth
import boto3
from botocore.exceptions import ClientError
import json
import os
from typing import Dict, Any
from aws_lambda_powertools import Logger, logging
from aws_lambda_powertools.utilities.typing import LambdaContext
from datetime import datetime

logger = Logger()
logger = Logger(level="INFO")
region = os.environ.get('REGION')

host = os.environ.get('OS_HOST')
service = 'aoss'
credentials = boto3.Session().get_credentials()
auth = AWSV4SignerAuth(credentials, region, service)
index_name = os.environ.get('INDEX')


# create an opensearch client and use the request-signer
client = OpenSearch(
    hosts=[{'host': host, 'port': 443}],
    http_auth=auth,
    use_ssl=True,
    verify_certs=True,
    connection_class=RequestsHttpConnection,
    pool_maxsize=20,
)
  
def query_grants(query_text: str) -> str:
    """Upload a file to an S3 bucket

    :param query_text: text to query opensearch with
    :return: Success
    """

    logger.info(f"query_grants {query_text} ")
    try:
        query = {
          'size': 100,
          'query': {
              'multi_match': {
                  'type': 'best_fields',
                  'fields': ['*'],
                  'query': query_text,
              }
          }
           
      }

  
        response = client.search(
          body = query,
          index = index_name
        )
        # Extract the hits while preserving the response structure
        hits = response['hits']['hits']
        
        # Sort the hits by Expired_Date
        sorted_hits = sorted(
            hits,
            key=lambda x: datetime.strptime(x['_source']['Expired_Date'], '%m/%d/%y'),
            reverse=True  # for descending order
        )
        
        # Reconstruct the response with sorted hits
        sorted_response = {
            'took': response['took'],
            'timed_out': response['timed_out'],
            '_shards': response['_shards'],
            'hits': {
                'total': response['hits']['total'],
                'max_score': response['hits']['max_score'],
                'hits': sorted_hits
            }
        }
        
        logger.info(f'\nSorted Search results: {sorted_response}')
        return response
    except Exception as e:
        logger.error(f"query_grants Exception {e}")
        raise e

def lambda_handler(event, context):
  try:
    logger.info(f'received event: {event}')

    queryStringParameters = event.get("queryStringParameters")
    if not queryStringParameters:
            raise ValueError("queryStringParameters is empty")
    queryText = queryStringParameters['searchtext']
    if not queryText:
            raise ValueError("queryText is empty")

    logger.info('Searching for: {queryText}')
    
    response = query_grants(queryText)
    logger.info(f"query_grants response {response}")
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Headers': '*',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        'body': json.dumps(response)
    }
  except Exception as e:
        logger.error(f"Exception {e}")
        return {
          'statusCode': 202,
          'headers': {
              'Content-Type': 'application/json',
              'Access-Control-Allow-Headers': '*',
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
              "X-Amz-Function-Error": str(e),
          },
          "body": json.dumps('{"response": "Exception "' + str(e) + "}"),
        }