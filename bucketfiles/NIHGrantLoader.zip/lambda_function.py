from opensearchpy import OpenSearch, RequestsHttpConnection, AWSV4SignerAuth
import boto3
from botocore.exceptions import ClientError
import csv
import json
import os
import time

from typing import Dict, Any
from aws_lambda_powertools import Logger, logging
from aws_lambda_powertools.utilities.typing import LambdaContext

logger = Logger()
logger = Logger(level="INFO")
region = os.environ.get("REGION")

region = os.environ.get("REGION")
host = os.environ.get("OS_HOST")
service = "aoss"
credentials = boto3.Session().get_credentials()
auth = AWSV4SignerAuth(credentials, region, service)


# create an opensearch client and use the request-signer
# Update the client configuration with longer timeouts
client = OpenSearch(
    hosts=[{"host": host, "port": 443}],
    http_auth=auth,
    use_ssl=True,
    verify_certs=False,
    ssl_show_warn=False,
    connection_class=RequestsHttpConnection,
    pool_maxsize=40,
    timeout=30,  # Increase timeout to 30 seconds
    max_retries=3,  # Add retry capability
    retry_on_timeout=True  # Retry on timeout
)

index_name = "grant-opportunities-index"


def delete_index(index_name: str) -> str:
    response = None

    try:
        # delete index
        response = client.indices.delete(index=index_name)
        logger.info(f"Index Deletion {response}")
        return response

    except Exception as e:
        logger.error(f"Exception thrown deleting index {e}")
        raise e


def check_index_exists(index_name: str, max_retries: int = 3, delay: float = 30.0) -> bool:
    """
    Check if index exists with retries
    """
    for attempt in range(max_retries):
        try:
            if client.indices.exists(index=index_name):
                logger.info(f"Index {index_name} exists (attempt {attempt + 1}/{max_retries})")
                return True
            logger.info(f"Index {index_name} does not exist, waiting {delay} seconds... (attempt {attempt + 1}/{max_retries})")
            time.sleep(delay)
        except Exception as e:
            logger.warning(f"Index existence check failed (attempt {attempt + 1}/{max_retries}): {e}")
            time.sleep(delay)
    return False


def bulk_index_documents(client, index_name: str, documents: list, batch_size: int = 25) -> dict:
    """
    Bulk index documents into OpenSearch with optimized batch size and error handling
    """
    if not client.indices.exists(index=index_name):
        raise Exception(f"Index {index_name} does not exist")
        
    success_count = 0
    error_count = 0
    bulk_data = []
    retry_queue = []
    
    total_documents = len(documents)
    logger.info(f"Starting bulk indexing of {total_documents} documents in batches of {batch_size}")
    
    # Initial indexing pass
    for cnt, document in enumerate(documents):
        action = {
            "_index": index_name,
            "_id": str(cnt)
        }
        
        bulk_data.extend([
            {"index": action},
            document
        ])
        
        if len(bulk_data) >= batch_size * 2:
            try:
                response = client.bulk(
                    body=bulk_data,
                    request_timeout=60
                )
                
                if response and 'items' in response:
                    for idx, item in enumerate(response['items']):
                        if 'index' in item:
                            if 'error' in item['index']:
                                doc_idx = (cnt - len(bulk_data)//2) + idx//2
                                if doc_idx < len(documents):
                                    retry_queue.append((str(doc_idx), documents[doc_idx]))
                                error_count += 1
                            elif item['index'].get('status') in [200, 201]:
                                success_count += 1
                
                progress = (cnt / total_documents) * 100
                if cnt % (batch_size * 4) == 0:  # Reduce logging frequency
                    logger.info(
                        f"Progress: {progress:.1f}% - Documents processed: {cnt}/{total_documents} - "
                        f"Success: {success_count}, Pending retries: {len(retry_queue)}"
                    )
                
                bulk_data = []
                time.sleep(1)
                
            except Exception as e:
                logger.error(f"Batch processing failed: {str(e)}")
                start_idx = cnt - len(bulk_data)//2
                for i in range(0, len(bulk_data), 2):
                    doc_idx = start_idx + i//2
                    if doc_idx < len(documents):
                        retry_queue.append((str(doc_idx), documents[doc_idx]))
                error_count += len(bulk_data) // 2
                bulk_data = []
                time.sleep(2)
    
    # Process remaining documents from first pass
    if bulk_data:
        try:
            response = client.bulk(
                body=bulk_data,
                request_timeout=60
            )
            
            if response and 'items' in response:
                for idx, item in enumerate(response['items']):
                    if 'index' in item:
                        if 'error' in item['index']:
                            doc_idx = (len(documents) - len(bulk_data)//2) + idx//2
                            if doc_idx < len(documents):
                                retry_queue.append((str(doc_idx), documents[doc_idx]))
                            error_count += 1
                        elif item['index'].get('status') in [200, 201]:
                            success_count += 1
                            
        except Exception as e:
            logger.error(f"Final batch processing failed: {str(e)}")
            start_idx = len(documents) - len(bulk_data)//2
            for i in range(0, len(bulk_data), 2):
                doc_idx = start_idx + i//2
                if doc_idx < len(documents):
                    retry_queue.append((str(doc_idx), documents[doc_idx]))
            error_count += len(bulk_data) // 2
    
    # Retry phase with smaller batches
    retry_success = 0
    if retry_queue:
        logger.info(f"Starting retry phase for {len(retry_queue)} documents...")
        retry_batch_size = 10
        retry_bulk_data = []
        
        for doc_id, doc in retry_queue:
            action = {
                "_index": index_name,
                "_id": doc_id
            }
            
            retry_bulk_data.extend([
                {"index": action},
                doc
            ])
            
            if len(retry_bulk_data) >= retry_batch_size * 2:
                try:
                    response = client.bulk(
                        body=retry_bulk_data,
                        request_timeout=60
                    )
                    
                    if response and 'items' in response:
                        for item in response['items']:
                            if 'index' in item and item['index'].get('status') in [200, 201]:
                                retry_success += 1
                                error_count -= 1
                    
                    retry_bulk_data = []
                    time.sleep(2)
                    
                except Exception as e:
                    logger.error(f"Retry batch failed: {str(e)}")
                    retry_bulk_data = []
                    time.sleep(3)
    
        # Handle remaining retry documents
        if retry_bulk_data:
            try:
                response = client.bulk(
                    body=retry_bulk_data,
                    request_timeout=60
                )
                
                if response and 'items' in response:
                    for item in response['items']:
                        if 'index' in item and item['index'].get('status') in [200, 201]:
                            retry_success += 1
                            error_count -= 1
                            
            except Exception as e:
                logger.error(f"Final retry batch failed: {str(e)}")
    
    final_stats = {
        "total_documents": total_documents,
        "successful_documents": success_count,
        "failed_documents": error_count,
        "retried_documents": len(retry_queue),
        "successful_retries": retry_success
    }
    
    logger.info(f"Indexing complete. Final stats: {final_stats}")
    return final_stats


def create_index(index_name: str) -> str:
    try:
        # Simplified settings for serverless - removing replica configuration
        index_body = {
            "settings": {
                "number_of_shards": 1
                # Removing number_of_replicas and write.wait_for_active_shards as they're managed by serverless
            }
        }

        # Create the index
        response = client.indices.create(
            index=index_name, 
            body=index_body
        )
        logger.info(f"Index Creation response: {response}")
        
        # Wait for index to be ready
        if wait_for_index_readiness(index_name):
            logger.info(f"Index {index_name} is ready for operations")
            return response
        else:
            raise Exception(f"Index {index_name} failed to become ready after creation")

    except Exception as e:
        logger.error(f"Exception thrown creating index: {e}")
        raise e

def wait_for_index_readiness(index_name: str, max_retries: int = 30, delay: float = 3.0) -> bool:
    """
    Wait for index to be ready using basic checks
    """
    for attempt in range(max_retries):
        try:
            time.sleep(delay)
            
            exists = client.indices.exists(index=index_name)
            logger.info(f"Index exists check: {exists} (attempt {attempt + 1}/{max_retries})")
            
            if not exists:
                continue
                
            try:
                settings = client.indices.get_settings(index=index_name)
                if settings:
                    logger.info(f"Index settings retrieved successfully: {settings}")
                    return True
                    
            except Exception as e:
                logger.warning(f"Failed to get index settings: {e}")
                continue

        except Exception as e:
            logger.warning(f"Index readiness check attempt {attempt + 1}/{max_retries} failed: {e}")
            time.sleep(delay)
            
    logger.error(f"Index {index_name} failed to become ready after {max_retries} attempts")
    return False


def wait_for_index_deletion(index_name: str, max_retries: int = 5, delay: float = 2.0) -> bool:
    """
    Wait for index to be fully deleted
    """
    for attempt in range(max_retries):
        try:
            time.sleep(delay)
            if not client.indices.exists(index=index_name):
                logger.info(f"Index {index_name} successfully deleted (attempt {attempt + 1}/{max_retries})")
                return True
            logger.info(f"Index {index_name} still exists, waiting... (attempt {attempt + 1}/{max_retries})")
        except Exception as e:
            logger.warning(f"Index deletion check attempt {attempt + 1}/{max_retries} failed: {e}")
    return False


def lambda_handler(event, context):
    try:
        logger.info("received event:")
        logger.info(event)

        # Delete existing index if it exists
        if client.indices.exists(index=index_name):
            result = delete_index(index_name)
            logger.info(f"Result from index deletion {result}")
            
            if not wait_for_index_deletion(index_name):
                raise Exception(f"Index {index_name} deletion did not complete")

        # Create new index
        logger.info("Creating new index...")
        result = create_index(index_name)
        logger.info(f"Result from index creation {result}")
        
        # Additional verification after creation
        if not client.indices.exists(index=index_name):
            raise Exception(f"Index {index_name} does not exist after creation")

        # Simple cluster health check without timeout
        try:
            health = client.cluster.health(index=index_name)
            logger.info(f"Cluster health before processing: {health}")
        except Exception as e:
            logger.warning(f"Cluster health check failed, but continuing: {e}")

        # Download and process CSV file
        s3 = boto3.client("s3")
        bucket = event["Records"][0]["s3"]["bucket"]["name"]
        key = event["Records"][0]["s3"]["object"]["key"]
        logger.info(f"bucket {bucket} key {key}")

        try:
            response = s3.get_object(Bucket=bucket, Key=key)
            csv_file = response["Body"].read().decode("utf-8").splitlines()
            csv_reader = csv.DictReader(csv_file, delimiter=",")
            
            # Convert CSV to list of documents
            documents = list(csv_reader)
            logger.info(f"Total documents to process: {len(documents)}")

            # Verify index exists before bulk indexing
            if not client.indices.exists(index=index_name):
                raise Exception(f"Index {index_name} does not exist before bulk indexing")

            # Perform bulk indexing
            indexing_result = bulk_index_documents(
                client=client,
                index_name=index_name,
                documents=documents,
                batch_size=100
            )
            
            logger.info(f"Bulk indexing completed: {indexing_result}")

            return {
                "statusCode": 200,
                "headers": {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Headers": "*",
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
                },
                "body": json.dumps(indexing_result),
            }

        except Exception as e:
            logger.error(f"Exception thrown processing documents: {str(e)}")
            raise e

    except Exception as e:
        logger.error(f"lambda_handler Exception str({e})")
        return {
            "statusCode": 202,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
                "X-Amz-Function-Error": str(e),
            },
            "body": json.dumps('{"response": "Exception "' + str(e) + "}"),
        }
