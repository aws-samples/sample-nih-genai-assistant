import boto3
from botocore.exceptions import ClientError
import json
import os
import time
import requests
from bs4 import BeautifulSoup
from typing import Dict, Any
from aws_lambda_powertools import Logger, logging
from aws_lambda_powertools.utilities.typing import LambdaContext

logger = Logger()
logger = Logger(level="INFO")
AWS_REGION = "us-east-2"
s3_client = boto3.client(
            service_name="s3",
            region_name=AWS_REGION,
        )

def upload_file_to_s3(file_name: str, bucket: str, object_name: str) -> str:
    """Upload a file to an S3 bucket

    :param file_name: File to upload
    :param bucket: Bucket to upload to
    :param runUUID:
    :return: True if file was uploaded, else False
    """

    logger.info(f"upload_file_to_s3 {file_name} {bucket} {object_name}")
    try:
      
        response = s3_client.upload_file(file_name, bucket, object_name)
        return response
    except ClientError as e:
        logger.error(f"upload_file Exception str({e})")
        raise e


def writerows(rows: str, filename: str) -> str:
    try:
        logger.info(f"writerows  {filename}")
        f = open(filename, "a", encoding="utf-8")
        # write text to file
        f.write(rows)
        f.close()
        return "Success"
    except Exception as e:
        logger.error(f"writerows Exception str({e})")
        raise e


def getContentForObjectAttribute(
    listingurl: str,
    object: str,
    object_attribute: str,
    attribute_value: str,
    filename: str,
) -> str:
    """
    scrape  data from the page and write
    """

    logger.info(
        f"getContentForObjectAttribute {listingurl} {object} {object_attribute} {attribute_value} {filename}"
    )

    # prepare headers
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0"
    }

    # fetching the url, raising error if operation fails
    try:
        response = requests.get(listingurl, headers=headers)
    except requests.exceptions.RequestException as e:
        logger.info(f"getContentForDivAttribute Exception str({e})")
        raise e

    soup = BeautifulSoup(response.text, "html.parser")

    for div in soup.find_all(object):
        try:
            logger.info(div.get_text)
            writerows(div.get_text(), filename)
        except Exception as e:
            logger.info(f"getContentForDivAttribute Exception str({e})")
            raise e
        #try:
        #    section_value = div[object_attribute]
        #except KeyError as ke:
        #    logger.info(f"KeyError {ke}")
        #    continue
        #logger.info(section_value)
        #try:
        #    if section_value == attribute_value:
        #        logger.info(div.get_text())
        #        writerows(div.get_text(), filename)
        #
        #except Exception as e:
        #   logger.info(f"getContentForDivAttribute Exception str({e})")
        #    raise e
        
        
    return "Success"


@logger.inject_lambda_context
def lambda_handler(event, context):
    logger.info("received event:")
    logger.info(event)
    os.chdir("/tmp")

    try:

        _s3Folder = os.environ.get("s3Folder")
        _s3Bucket = os.environ.get("S3_OUTPUT_BUCKET")

        runUUID = event["queryStringParameters"]["runUUID"]
        baseurl = event["queryStringParameters"]["baseurl"]
        contextFile = event["queryStringParameters"]["contextFile"]
        htmlObject = event["queryStringParameters"]["htmlObject"]
        htmlObjectAttribute = event["queryStringParameters"]["htmlObjectAttribute"]
        htmlObjectAttributeValue = event["queryStringParameters"][
            "htmlObjectAttributeValue"
        ]

        s3Folder = _s3Folder
        s3Bucket = _s3Bucket

        logger.info(f"runUUID {runUUID}")
        if not runUUID:
            raise ValueError("run_uuid is empty")
        logger.info(f"baseurl {baseurl}")
        if not baseurl:
            raise ValueError("baseurl is empty")
        logger.info(f"s3Folder {s3Folder}")
        if not s3Folder:
            raise ValueError("s3Folder is empty")
        logger.info(f"s3Bucket {s3Bucket}")
        if not s3Bucket:
            raise ValueError("s3Bucket is empty")
        logger.info(f"contextFile {contextFile}")
        if not contextFile:
            raise ValueError("contextFile is empty")
        logger.info(f"htmlObject {htmlObject}")
        if not htmlObject:
            raise ValueError("htmlObject is empty")
        logger.info(f"htmlObjectAttribute {htmlObjectAttribute}")
        if not htmlObjectAttribute:
            raise ValueError("htmlObjectAttribute is empty")
        logger.info(f"htmlObjectAttributeValue {htmlObjectAttributeValue}")
        if not htmlObjectAttributeValue:
            raise ValueError("htmlObjectAttributeValue is empty")

        filename = contextFile + ".txt"
        lambda_filename = "/tmp/" + filename
        logger.info(f"lambda_filename {lambda_filename}")
        logger.info(f"filename {filename}")

        if os.path.exists(filename):
            logger.info("file exists, removing ")
            os.remove(filename)

        # scrape for div attributes

        logger.info("getContentForDivAttribute ")
        listingurl = baseurl
        response = getContentForObjectAttribute(
            listingurl,
            htmlObject,
            htmlObjectAttribute,
            htmlObjectAttributeValue,
            lambda_filename,
        )
        logger.info(f"getContentForDivAttribute response {response}")
        time.sleep(1)

        logger.info("upload_file_to_s3 ")
        response = upload_file_to_s3(
            lambda_filename,
            s3Bucket,
            "{}{}{}{}".format(s3Folder, runUUID, "/", filename),
        )

        return {
            "statusCode": 200,

            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
            },
            "body": json.dumps('{"response": "Success"}'),
        }

    except Exception as e:
        logger.error(f"lambda_handler Exception str({e})")
        return {
            "statusCode": 202,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
                "X-Amz-Function-Error": str(e),
            },
            "body": json.dumps('{"response": "Exception "' + str(e) + "}"),
        }
