import json
import os
import boto3
from typing import Dict, Any
from aws_lambda_powertools import Logger, logging
from aws_lambda_powertools.utilities.typing import LambdaContext

logger = Logger()
logger = Logger(level="INFO")


def set_default(obj):
    """
    Helper function to convert sets to lists for JSON serialization.

    Args:
        obj: The object to be checked and converted if it's a set.

    Returns:
        list: If the input object is a set, returns a list with the same elements.
        Raises TypeError if the input object is not a set.
    """

    if isinstance(obj, set):
        return list(obj)
    raise TypeError
    
def list_files_in_folder(bucket_name: str, run_uuid: str) -> Dict:
    
    """
    Lists all files in the specified S3 bucket and folders for a given run UUID.

    Args:
        bucket_name (str): The name of the S3 bucket to search.
        run_uuid (str): The UUID of the run for which files should be listed.

    Returns:
        Dict: A list of dictionaries, where each dictionary contains the file name and description.
    """

    try:
        s3_client = boto3.client('s3')
    
        # 
        responseList = []
     
        response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix='artifacts/grant-description/'+run_uuid)
        logger.info(response)
     
        if 'Contents' in response:
        
            for obj in response['Contents']:
                logger.info(obj['Key'])
                obj_key = {"file_name": str(obj['Key']), "description": "Grant Description"}
                responseList.append(obj_key)
        else:
            logger.info("Folder is empty.")
    
        response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix='artifacts/aims-doc/'+run_uuid)
        #logger.info(f'response {response}')
     
        if 'Contents' in response:
        
            for obj in response['Contents']:
                logger.info(obj['Key'])
                obj_key = {"file_name": str(obj['Key']), "description": "AIMs Docs"}
                responseList.append(obj_key)
        else:
            logger.info("Folder is empty.")
            
        response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix='artifacts/customer-uploads/'+run_uuid)
        #logger.info(f'response {response}')
     
        if 'Contents' in response:
        
            for obj in response['Contents']:
                logger.info(obj['Key'])
                obj_key = {"file_name": str(obj['Key']), "description": "Customer Docs"}
                responseList.append(obj_key)

        else:
            logger.info("Folder is empty.")
            
            
        response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix='artifacts/nih-reporter/'+run_uuid)
        #logger.info(f'response {response}')
     
        if 'Contents' in response:
        
            for obj in response['Contents']:
                logger.info(obj['Key'])
                obj_key = {"file_name": str(obj['Key']), "description": "NIHR Docs"}
                responseList.append(obj_key)

        else:
            logger.info("Folder is empty.")    
     
        logger.info(type(responseList))
        return responseList
    
    except Exception as e:
        logger.info(e)
        raise(e)

@logger.inject_lambda_context
def lambda_handler(event, context):
    """
    AWS Lambda function handler.

    Args:
        event (dict): The event data received by the Lambda function.
        context (LambdaContext): The Lambda context object.

    Returns:
        dict: A dictionary containing the response data with the following keys:
            - statusCode (int): The HTTP status code of the response.
            - headers (dict): The headers for the response.
            - body (str): The response body as a JSON-serialized string.
    """

    try:
        logger.info(f"Received event: json.dumps({event}, indent=2)")

        s3Bucket = os.environ.get("S3_OUTPUT_BUCKET")

        query_string_parameters = event.get("queryStringParameters")
        if not query_string_parameters:
            raise ValueError("query_string_parameters is empty")
        run_uuid = query_string_parameters["runUUID"]
        if not run_uuid:
            raise ValueError("run_uuid is empty")
        logger.info(f"run_uuid {run_uuid}")

        
        response = list_files_in_folder(s3Bucket,  run_uuid)
        logger.info(f"query response {response}")
        res = {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Credentials": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "*",
            },
            "body": json.dumps(response,default=set_default),
        }

        logger.info(f"response success in handler {res}")

        return res

    except Exception as e:
        logger.info(f"Exception raised str({e})")

        res = {
            "statusCode": 202,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Credentials": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "*",
                "X-Amz-Function-Error": str(e),
            },
            "body": json.dumps({"result": "Exception " + str(e)}),
        }
        logger.info(f"response *** Exception *** in handler {res}")
        return res
