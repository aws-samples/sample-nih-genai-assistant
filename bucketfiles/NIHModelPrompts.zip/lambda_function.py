import json
import os
import boto3
from typing import Dict, Any
from aws_lambda_powertools import Logger, logging
from aws_lambda_powertools.utilities.typing import LambdaContext
from decimal import Decimal

logger = Logger()
logger = Logger(level="INFO")
dynamodb = boto3.resource("dynamodb")

#
def decimal_serializer(obj):
    """
    Serialize Decimal objects to strings when converting Python objects to JSON.

    Args:
        obj (Any): The object to be serialized.

    Returns:
        str: The serialized string representation of the object.

    Raises:
        TypeError: If the object is not a Decimal instance.
    """
     
    if isinstance(obj, Decimal):
        return str(obj)
    raise TypeError("Type not serializable")
    
# query an item from dynamodb table
def query_item(table_name: str, key_name: str) -> Dict:
    """
    Query an item from a DynamoDB table.

    Args:
        table_name (str): The name of the DynamoDB table.
        key_name (str): The name of the key attribute.

    Returns:
        Dict: A list of items retrieved from the DynamoDB table.

    Raises:
        ValueError: If the table name or key name is empty.
        Exception: If any other exception occurs during the query operation.
    """

    logger.info("query_item")
    if not table_name:
        raise ValueError("Table name cannot be empty")

    if not key_name:
        raise ValueError("Key name cannot be empty")
        
    logger.info(f"query_item table_name {table_name}" )
    logger.info(f"query_item key_name {key_name}")

    prompts = []
    key_values = []
    key_values.append("ab4cf5bf-AIMS-P1")
    key_values.append("ab4cf5bf-GRANT-P1")
    key_values.append("ab4cf5bf-GRANT-P2")
  


   

    try:

        table = dynamodb.Table(table_name)
        
        for index, key in enumerate(key_values):
            
            logger.info(index,key)
            key_value = key
            response = table.get_item(
            Key={
                key_name: key
            }
            )
            if 'Item' in response:
                logger.info(f"Item with {key_name}={key_value} exists in the table.")
                logger.info(f"response {response['Item']}")
            
                prompts.append(response['Item'])
            else:
                logger.info(f"Item with {key_name}={key_value} does not exist in the table.")
                response = {"result": "NotFound"}
                
        
        return prompts
    except Exception as e:
        logger.error(f"query_item exception {e}")
        raise e


@logger.inject_lambda_context
def lambda_handler(event, context):
    """
    AWS Lambda handler function.

    Args:
        event (Dict): The event data received by the Lambda function.
        context (LambdaContext): The Lambda context object.

    Returns:
        Dict: The response object to be returned by the Lambda function.
    """
    
    try:
        logger.info(f"Received event: json.dumps({event}, indent=2)")

        response = query_item("nih-grants-table", "id")
        logger.info(f"query response {response}")
        res = {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Credentials": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "*",
            },
            "body": json.dumps(response, default=decimal_serializer),
        }

        logger.info(f"response success in handler {res}")

        return res

    except Exception as e:
        logger.info(f"Exception raised str({e})")

        res = {
            "statusCode": 202,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Credentials": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "*",
                "X-Amz-Function-Error": str(e),
            },
            "body": json.dumps({"result": "Exception " + str(e)}),
        }
        logger.info(f"response *** Exception *** in handler {res}")
        return res
