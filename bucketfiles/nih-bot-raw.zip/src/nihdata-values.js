export const nihdata = 
    {
      wss: "wss://u86if5vfbf.execute-api.us-east-1.amazonaws.com/Dev/",
      school: "UM",
      ak: "07Fd9wR07r5i6p6v3goxR3gJrTcGJ3Gb26h3z9uq",
    }
