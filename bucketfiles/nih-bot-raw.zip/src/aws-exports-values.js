
const awsmobile = {
    "aws_project_region": "PLACEHOLDER - REGION",
    //
    // 
    //
    "aws_cloud_logic_custom": [
        {
            "name": "nihGrantsApi",
            "endpoint": "PLACEHOLDER - API URL",
            "region": "PLACEHOLDER - REGION"
        }
    ],
    "aws_cognito_identity_pool_id": "PLACEHOLDER - IPID",
    "aws_cognito_region": "PLACEHOLDER - REGION",
    "aws_user_pools_id": "PLACEHOLDER - UPID",
    "aws_user_pools_web_client_id": "PLACEHOLDER - UPWCID",
    "oauth": {},
    "aws_cognito_username_attributes": [],
    "aws_cognito_social_providers": [],
    "aws_cognito_signup_attributes": [
        "EMAIL"
    ],
    "aws_cognito_mfa_configuration": "OFF",
    "aws_cognito_mfa_types": [
        "SMS"
    ],
    "aws_cognito_password_protection_settings": {
        "passwordPolicyMinLength": 8,
        "passwordPolicyCharacters": []
    },
    "aws_cognito_verification_mechanisms": [
        "EMAIL"
    ],
    "aws_user_files_s3_bucket": "PLACEHOLDER - S3CB",
    "aws_user_files_s3_bucket_region": "PLACEHOLDER - REGION",
    "level": "public",
    "selectedGuestPermissions": [
        "s3:GetObject",
        "s3:DeleteObject",
        "s3:ListBucket"
    ],
    "selectedAuthenticatedPermissions": [
        "s3:PutObject",
        "s3:DeleteObject",
        "s3:ListBucket"
    ],
};


export default awsmobile;
