export const nihdata = 
    {
      wss: "PLACEHOLDER - WSS",
      school: "UM",
      ak: "PLACEHOLDER - AK",
    }
