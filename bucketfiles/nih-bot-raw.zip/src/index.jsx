import React from 'react';
import ReactDOM, { createRoot } from 'react-dom/client';
import './index.css';
import App from './App';


import {Amplify}  from "aws-amplify";
import awsconfig from "./aws-exports";
Amplify.configure(awsconfig);

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
//const root = ReactDOM.createRoot(document.getElementById('root'));
//root.render(
  //<React.StrictMode>
   // <App />
  //</React.StrictMode>
//);


