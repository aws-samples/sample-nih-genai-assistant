import React, { useState } from "react";

import "./App.css";
import Home from "./Components/Home";
import Admin from "./Components/Admin";
import NIHR from "./Components/NIHR";
import Upload from "./Components/Upload";
import UploadGeneric from "./Components/UploadGeneric";
import AIMsUpload from "./Components/AIMsUpload";
import TemplateGen from "./Components/TemplateGen";
import TemplateGenGeneric from "./Components/TemplateGenGeneric";
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="/Home" element={<Home />}></Route>
        <Route path="/Admin" element={<Admin />}></Route>
        <Route path="/NIHR" element={<NIHR />}></Route>
        <Route path="/Upload" element={<Upload />}></Route>
        <Route path="/UploadGeneric" element={<UploadGeneric />}></Route>
        <Route path="/AIMsUpload" element={<AIMsUpload />}></Route>
        <Route path="/TemplateGen" element={<TemplateGen />}></Route>
        <Route path="/TemplateGenGeneric" element={<TemplateGenGeneric />}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
