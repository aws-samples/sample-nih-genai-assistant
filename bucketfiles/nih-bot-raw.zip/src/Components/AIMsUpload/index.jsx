import React, { useState, useEffect } from "react";
import "./index.css";
import { withAuthenticator } from "@aws-amplify/ui-react";
import "@aws-amplify/ui-react/styles.css";
import { appLayoutLabels } from "../labels";
import { SignatureV4 } from "@smithy/signature-v4";
import { HttpRequest } from "@smithy/protocol-http";
import { Sha256 } from "@aws-crypto/sha256-js";
import { fetchAuthSession } from "@aws-amplify/auth";
import {
  AppLayout,
  Box,
  Header,
  HelpPanel,
  Button,
  Form,
  Container,
  TextContent,
  FormField,
  FileUpload,
  ProgressBar,
  SpaceBetween,
  Spinner,
  Alert,
  Table,
  Pagination,
} from "@cloudscape-design/components";
import Navigation from "../Navigation";
import { Amplify } from "aws-amplify";
import awsconfig from "../../aws-exports";
import { uploadData } from "aws-amplify/storage";
import { useNavigate } from "react-router-dom";
import { nihdata } from "../../nihdata";


Amplify.configure(awsconfig, {
  Storage: {
    S3: {
      prefixResolver: async ({ accessLevel, targetIdentityId }) => {
        if (accessLevel === "guest") {
          return "artifacts/";
        } else if (accessLevel === "protected") {
          return `artifacts/${targetIdentityId}/`;
        } else {
          return `artifacts/${targetIdentityId}/`;
        }
      },
    },
  },
});

var _uploadedDocs = [];
const Content = () => {
  const [runUUID, setRunUUID] = useState(() => {
    console.log("GETTING LOCAL STORAGE");
    const savedItem = localStorage.getItem("runUUID");
    const parsedItem = JSON.parse(savedItem);
    console.log("GETTING LOCAL STORAGE " + parsedItem);
    return parsedItem || "";
  });

  const [uploadedDocs, setUploadedDocs] = React.useState([]);
  const [isSpinning, setIsSpinning] = React.useState("inverted");
  const [value, setValue] = React.useState([]);
  const [progressBarValue, setProgressBarValue] = React.useState(0);
  const [progressStatus, setProgressStatus] = React.useState("success");
  const [submitDisabled, setSubmitDisabled] = React.useState(false);
  const [alertVisible, setAlertVisible] = React.useState(false);
  const [alertText, setAlertText] = React.useState("No files to updload");
  const [alertType, setAlertType] = React.useState("error");
  const [contextButtonDisabled, setContextButtonDisabled] =
    React.useState(true);
  const navigate = useNavigate();
  const collectDocumentContext = async () => {
    console.log("collectDocumentContext");

    navigate("/Upload", {});
  };

  const skipContext = () => {
    console.log("");
    navigate("/Upload", {});
  };
  const cancel = async (event) => {
    setUploadedDocs([]);
  };
  function addElement(newValue) {
    setUploadedDocs((prevUploadedDocs) => [...prevUploadedDocs, newValue]);
    return;
  }
  const generateWebSocketUrl = async () => {
    try {
      const session = await fetchAuthSession();
      const credentials = {
        accessKeyId: session.credentials.accessKeyId,
        secretAccessKey: session.credentials.secretAccessKey,
        sessionToken: session.credentials.sessionToken
      };
  
      // Verify credentials
      if (!credentials.accessKeyId || !credentials.secretAccessKey || !credentials.sessionToken) {
        throw new Error('Invalid credentials');
      }
  
      // Get the original URL and remove the trailing slash
      const cleanUrl = nihdata.wss;
      //const cleanUrl = originalUrl.replace(/\/+\$/, ''); // Remove trailing slashes
      
      console.log('Original WSS URL:', cleanUrl);
      console.log('Clean WSS URL:', cleanUrl);
  
      // Parse the cleaned WebSocket URL
      const endpoint = new URL(cleanUrl);
  
      // Extract region from hostname (format: <api-id>.execute-api.<region>.amazonaws.com)
      const hostnameComponents = endpoint.hostname.split('.');
      let region = 'us-east-1'; // Default fallback
      
      // Check if hostname follows expected pattern
      if (hostnameComponents.length >= 4 && 
          hostnameComponents[1] === 'execute-api' && 
          hostnameComponents[3] === 'amazonaws') {
        region = hostnameComponents[2];
      }
      
      console.log('Extracted region:', region);
  
      // Create the signer with the extracted region
      const signer = new SignatureV4({
        credentials: credentials,
        region: region,
        service: 'execute-api',
        sha256: Sha256
      });
  
      // Create the HTTP request object with the clean path
      const request = new HttpRequest({
        method: 'GET',
        protocol: endpoint.protocol,
        hostname: endpoint.hostname,
        path: endpoint.pathname,
        headers: {
          host: endpoint.hostname
        }
      });
  
      // Presign the request
      const presigned = await signer.presign(request, {
        expiresIn: 300 // 5 minutes
      });
  
      // Convert the presigned request to a WebSocket URL
      const queryParams = new URLSearchParams();
      Object.entries(presigned.query || {}).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          queryParams.append(key, value);
        }
      });
  
      // Use the clean URL, not the original with trailing slash
      const wsUrl = `${cleanUrl}?${queryParams.toString()}`;
      console.log('Final WebSocket URL:', wsUrl);
      
      return wsUrl;
  
    } catch (error) {
      console.error('Error generating signed URL:', error);
      throw error;
    }
  };
  




  const submitForm = async (event) => {
    setAlertText("");
    setContextButtonDisabled(true);
    if (value.length > 0) {
      setIsSpinning("normal");
      setSubmitDisabled(true);
      setProgressStatus("in-progress");
      console.log("json " + JSON.stringify(value));
      console.log("fileChanged " + value[0].name);
      console.log("length " + value.length);

      try {
        var pdfN = value[0].name.indexOf(".pdf");
        var txtN = value[0].name.indexOf(".txt");
        console.log("pdfN " + pdfN);
        console.log("txtN " + txtN);
        if (
          value[0].name.indexOf(".pdf") === -1 &&
          value[0].name.indexOf(".txt") === -1
        ) {
          alert("Only .txt or .pdf files allowed");
          setSubmitDisabled(false);
          return;
        } else {
          console.log("PDF or  TXT found");
        }
        console.log("NO");
        var filenameStripped = value[0].name.replace(
          /[`~!@#$%^&*()_|+\-=?;:'",<>\{\}\[\]\\\/]/gi,
          ""
        );
        filenameStripped = filenameStripped.replace(/\s+/g, "-").toLowerCase();
        console.log("CHANGED FILE " + filenameStripped);
        const result = await uploadData({
          key: "aims-doc/" + runUUID + "/" + filenameStripped,
          data: value[0],
          options: {
            onProgress: ({ transferredBytes, totalBytes }) => {
              if (totalBytes) {
                console.log(
                  `Upload progress ${
                    Math.round(transferredBytes / totalBytes) * 100
                  } %`
                );
                setProgressBarValue((transferredBytes / totalBytes) * 100);
              }
            },
          },
        }).result;

        console.log("Succeeded:  ", result);
        //
        //
        //

        if (value[0].name.indexOf(".pdf") !== -1) {
          console.log("pdf file set listener");
          setAlertText(
            "PDF document is being converted to text, WAIT until complete before choosing another file"
          );
          setAlertVisible(true);
          setAlertType("warning");

          const signedUrl = await generateWebSocketUrl();
          const socket = new WebSocket(signedUrl);


          socket.addEventListener("message", (event) => {
            console.log("Message from server ", event);
            var message = event.data;
            console.log(message);
            var jsonMessage = JSON.parse(message);
            console.log("jsonMessage " + jsonMessage.message);

            if (jsonMessage.message === "PDF Converted") {
              console.log("PDF Converted");
              setAlertText("PDF document successfully converted to text");
              setAlertVisible(true);
              setAlertType("success");
              setIsSpinning("inverted");

              setValue([]);
              setProgressStatus("success");
              //setSubmitDisabled(false);
              socket.close();
            }

            var filenameStripped = value[0].name.replace(
              /[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi,
              ""
            );
            console.log(filenameStripped);
            addElement({ fileName: filenameStripped });
            console.log("uploadedDocs " + uploadedDocs);

            setContextButtonDisabled(false);
          });
          // disconnect socket
          socket.addEventListener("close", (event) => {
            console.log("Socket closed ", event);
            if (!event.wasClean) {
              // This indicates an abnormal closure (connection lost, network error, etc.)
              setValue([]);
              setProgressStatus("error");
              setAlertVisible(true);
              setAlertText("You encountered a network error ");
              setSubmitDisabled(false);
          } else {
              // Normal closure
              setValue([]);
              setProgressStatus("success");
              setSubmitDisabled(false);
          }

            
          });
        } else {
          var filenameStripped = value[0].name.replace(
            /[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi,
            ""
          );
          console.log(filenameStripped);

          addElement({ fileName: filenameStripped });
          console.log("uploadedDocs " + uploadedDocs);

          setContextButtonDisabled(false);

          setValue([]);
          setProgressStatus("success");
          setIsSpinning("inverted");
          setSubmitDisabled(false);
        }

        //
        //
        //
      } catch (error) {
        console.log("Error : ", error);
        setProgressStatus("status");
        setSubmitDisabled(false);
        setAlertText(JSON.stringify(error));
        setAlertVisible(true);
        setContextButtonDisabled(false);
      }
    } else {
      console.log("No files to upload");
      setAlertText("No files to upload");
      setAlertVisible(true);
      setSubmitDisabled(false);
      setContextButtonDisabled(false);
      setAlertType("error");
    }
  };

  const fileChanged = (detail) => {
    setValue(detail.value);
    setAlertText("");
    setAlertVisible(false);
  };
  const dismissAlert = (event) => {
    setAlertVisible(false);
  };

  return (
    <div className="search">
      <Alert
        dismissible
        statusIconAriaLabel="Error"
        type={alertType}
        onDismiss={() => dismissAlert()}
        visible={alertVisible}
      >
        {alertText}
      </Alert>
      <Form
        actions={
          <SpaceBetween direction="horizontal" size="xs">
            <Button onClick={(event) => cancel(event)} variant="link">
              {" "}
              Cancel
            </Button>
            <Button
              disabled={submitDisabled}
              onClick={(event) => submitForm(event)}
              variant="primary"
            >
              Submit
            </Button>
            <Button
              disabled={submitDisabled}
              onClick={(event) => skipContext(event)}
              variant="primary"
            >
              Skip
            </Button>
          </SpaceBetween>
        }
      >
        <Container
          media={{
            content: <img src="/AIMS.png" alt="placeholder" />,
            position: "side",
            width: "25%",
          }}
        >
          <FormField
            label="AIMs Context Upload"
            description="Upload PDF or text files"
          >
            <FileUpload
              onChange={({ detail }) => fileChanged(detail)}
              value={value}
              fileErrors={[""]}
              i18nStrings={{
                uploadButtonText: (e) => (e ? "Choose file" : "Choose file"),
                dropzoneText: (e) =>
                  e ? "Drop AIMs file to upload" : "Drop AIMs file to upload",
                removeFileAriaLabel: (e) => `Remove file ${e + 1}`,
                limitShowFewer: "Show fewer files",
                limitShowMore: "Show more files",
                errorIconAriaLabel: "Error",
              }}
              showFileLastModified
              showFileSize
              showFileThumbnail
              tokenLimit={3}
              constraintText=""
            />
          </FormField>
          <Spinner size="large" variant={isSpinning} />
        </Container>
       
      </Form>
      <div className="progress">
        <ProgressBar
          value={progressBarValue}
          additionalInfo=""
          description=""
          status={progressStatus}
          label="Upload Progress"
        />
      </div>

      <TextContent></TextContent>
      <SpaceBetween size="l">
        <Table
          columnDefinitions={[
            {
              id: "fileName",
              header: "File Name",
              cell: (e) => e.fileName,
              sortingField: "fileName",
              isRowHeader: true,
            },
          ]}
          columnDisplay={[{ id: "fileName", visible: true }]}
          items={uploadedDocs}
          loadingText="Loading resources"
          empty={
            <Box margin={{ vertical: "xs" }} textAlign="center" color="inherit">
              <SpaceBetween size="m">
                <b>No resources</b>
              </SpaceBetween>
            </Box>
          }
          header={<Header>Uploaded Resources</Header>}
          pagination={<Pagination currentPageIndex={1} pagesCount={1} />}
        />
      </SpaceBetween>

      <Container fitHeight>
        <SpaceBetween size="l">
          <Button
            onClick={(event) => collectDocumentContext(event)}
            disabled={contextButtonDisabled}
            variant="primary"
          >
            Use these Documents as context to generate the template{" "}
          </Button>
          <TextContent></TextContent>
        </SpaceBetween>
      </Container>
    </div>
  );
};

const SideHelp = () => (
  <div className="help">
    <HelpPanel header={<h2>AIMs Context Uploads</h2>}>
      <SpaceBetween size="m">
        <TextContent>
          After you have decided the area of research to pursue, start thinking
          about your planned experiments by first drafting objectives, known in
          NIH lingo as Specific Aims.
        </TextContent>
        <TextContent>
          You can start generating some ideas in your local AIMs document and
          upload them in this screen. These AIMs will be used to generate an NIH
          formatted AIMs document or they can be used to help generate the full
          Grant Proposal based on what you select in the Template Generation
          screen.
        </TextContent>
        <TextContent>
          Files you upload must be .txt or .pdf. PDF files will go through a conversion process and you meed to wait for the green success alert at the top of the screen before uploading another document. Text files are done when the progress bar is complete. To upload, select "Choose file", find a file on your local system, and hit submit.
        </TextContent>
        <TextContent>
        When you are done uploading documents, select the <strong>"Use these Documents as context to generate the template"</strong>. . That will upload the Grant Abstract to
        S3 and move you to the next Screen once you click the Green OK button.
        </TextContent>
        <hr />
        <SpaceBetween size="m">
          {" "}
          <TextContent>
            You can choose to skip this screen and can always go back to it in
            the left Navigation bar{" "}
          </TextContent>
        </SpaceBetween>
      </SpaceBetween>
    </HelpPanel>
  </div>
);

function AIMsUpload({ signOut, user }) {
  const [User, setUser] = useState(user);
  const [completedItems, setCompletedItems] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  if (process.env.NODE_ENV === "development")
    console.log("The Upload setup begins ---------->");

  useEffect(() => {
    if (process.env.NODE_ENV === "development")
      console.log("useEffect called .  .  ." + JSON.stringify(user));

    try {
      setUser(user);
      setIsLoading(false);
    } catch (e) {
      setIsLoading(false);
      if (process.env.NODE_ENV === "development")
        console.log(JSON.stringify(e));
    } finally {
      if (process.env.NODE_ENV === "development") console.log("finally");
    }
  }, [user]);
  if (process.env.NODE_ENV === "development") console.log("After useEffect ");

  const [lnavopen, setLnavopen] = useState(true);
  const [rnavopen, setRnavopen] = useState(false);

  const navChange = (detail) => {
    setLnavopen(detail.open);
  };
  const toolsChange = (detail) => {
    setRnavopen(detail.open);
  };

  if (!isLoading) {
    return (
      <AppLayout
        disableContentPaddings={false}
        navigation={<Navigation user={user} path="1"/>}
        content={<Content />}
        contentType="default"
        tools={<SideHelp />}
        toolsOpen={rnavopen}
        toolsWidth={300}
        navigationOpen={lnavopen}
        onNavigationChange={({ detail }) => navChange(detail)}
        onToolsChange={({ detail }) => toolsChange(detail)}
        ariaLabels={appLayoutLabels}
      />
    );
  } else {
    return (
      <Container>
        <TextContent>Loading . . . </TextContent>
      </Container>
    );
  }
}

export default withAuthenticator(AIMsUpload);
