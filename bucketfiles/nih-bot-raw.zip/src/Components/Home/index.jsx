import React, { useState, useEffect } from "react";
import "./index.css";
import { get, post } from "aws-amplify/api";
import { withAuthenticator, Authenticator } from "@aws-amplify/ui-react";
import "@aws-amplify/ui-react/styles.css";
import "@cloudscape-design/global-styles/index.css";
import { fetchAuthSession } from "@aws-amplify/auth";
import {
  AppLayout,
  HelpPanel,
  Table,
  Box,
  SpaceBetween,
  Button,
  Spinner,
  TextFilter,
  Header,
  Pagination,
  Link,
  Container,
  Alert,
  TextContent,
} from "@cloudscape-design/components";

import Navigation from "../Navigation";
import { useNavigate, useLocation } from "react-router-dom";
import { Amplify } from "aws-amplify";
import awsconfig from "../../aws-exports";
import { uploadData } from "aws-amplify/storage";
import { nihdata } from "../../nihdata";

Amplify.configure(awsconfig, {
  Storage: {
    S3: {
      prefixResolver: async ({ accessLevel, targetIdentityId }) => {
        if (accessLevel === "guest") {
          console.log("guest " + targetIdentityId);
          return "artifacts/";
        } else if (accessLevel === "protected") {
          console.log("targetIdentityId " + targetIdentityId);
          return `artifacts/${targetIdentityId}/`;
        } else {
          console.log("targetIdentityId 2" + targetIdentityId);
          return `artifacts/${targetIdentityId}/`;
        }
      },
    },
  },
});

const Content = () => {
  const [accessToken, setAccessToken] = useState(null);

  const [runUUID, setRunUUID] = React.useState(uuidv4());
  const [currentPageIndex, setCurrentPageIndex] = useState(1);
  const itemsPerPage = 25;
  useEffect(() => {
    localStorage.setItem("runUUID", JSON.stringify(runUUID));
    console.log("SETTING LOCAL STORAGE " + runUUID);

    async function getTokens() {
      try {
        const session = await fetchAuthSession(); // Fetch the authentication session
        //console.log('Access Token:', session.tokens.accessToken.toString());
        setAccessToken(session.tokens.idToken.toString());
        //console.log('ID Token:', session.tokens.idToken.toString());
      } catch (error) {
        console.error("Error fetching tokens:", error);
      }
    }
    getTokens();
  }, [runUUID]);

  const [filteringText, setFilteringText] = React.useState("");
  const [isSpinning, setIsSpinning] = React.useState("inverted");
  const [alertType, setAlertType] = React.useState("success");
  const [alertText, setAlertText] = React.useState(
    "Your grant has been selected and the context added."
  );
  const [grants, setGrants] = React.useState([]);
  const [selectedItems, setSelectedItems] = React.useState([{ Title: "" }]);
  const [submitDisabled, setSubmitDisabled] = React.useState(true);
  const [contextButtonDisabled, setContextButtonDisabled] =
    React.useState(true);
  const [sortDescending, setSortDescending] = React.useState(false);
  const navigate = useNavigate();
  const filteringTextChange = (detail) => {
    setFilteringText(detail);
    setSubmitDisabled(false);
  };
  const [alertVisible, setAlertVisible] = React.useState(false);
  const pagesCount = Math.ceil(grants.length / itemsPerPage);
  const clearSearchText = (event) => {
    console.log("clearSearchText");
    setSubmitDisabled(true);
    setContextButtonDisabled(true);
    setFilteringText("");
    setGrants([]);
    setIsSpinning("inverted");
    setAlertVisible(false);
  };
  // Calculate the current page's items
  const getCurrentPageItems = () => {
    const startIndex = (currentPageIndex - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return grants.slice(startIndex, endIndex);
  };
  const submitSearch = (params) => {
    console.log("submitSearch");
    setAlertVisible(false);
    setIsSpinning("normal");
    console.log("filteringText " + filteringText);
    if (filteringText.length <= 4) {
      setAlertVisible(true);
      setAlertType("error");
      setAlertText("Please enter a search term longer than 4 characters.");
      setIsSpinning("inverted");
      return;
    }
    searchNIHGrants();
  };

  function uuidv4() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
      /[xy]/g,
      function (c) {
        const r = (Math.random() * 16) | 0,
          v = c === "x" ? r : (r & 0x3) | 0x8;
        return v.toString(16);
      }
    );
  }
  const collectURLContext = (event) => {
    // collect URL Content
    
    setContextButtonDisabled(true);
    setSubmitDisabled(true);
    console.log("selectedItems " + JSON.stringify(selectedItems[0]));
    uploadDocNo(selectedItems[0].Document_Number);
    //var response = scrapeNIHGrantURL(selectedItems[0], runUUID);
    //console.log("response from scrape" + response);
    //uploadDocNo(selectedItems[0]);
    //console.log("response " + response);
  };

  const uploadDocNo = async (docno) => {
    if (docno === "" || docno === null) {
      docno = "unknown";
    }
    console.log("uploadDocNo " + docno);

    try {
      const result = await uploadData({
        key: "grant-description/" + runUUID + "/" + docno,
        data: docno,
        options: {
          onProgress: ({ transferredBytes, totalBytes }) => {
            if (totalBytes) {
              console.log(
                `Upload progress ${
                  Math.round(transferredBytes / totalBytes) * 100
                } %`
              );
              //setProgressBarValue((transferredBytes / totalBytes) * 100);
            }
          },
        },
      }).result;

      console.log("upload result " + result);
      setAlertVisible(true);
      setAlertType("success");
      setAlertText("Your grant has been selected and the context added.");
      return;
    } catch (e) {
      console.log("uploadDocNo failed: ", JSON.stringify(e));
      setAlertType("error");
      setAlertText("Exception Thrown " + JSON.stringify(e));
      setAlertVisible(true);
      setSubmitDisabled(false);
    }
  };
  const nextNavigation = (event) => {
    console.log("nextNavigation alertType " + JSON.stringify(alertType));
    if (alertType === "error") {
      setAlertVisible(false);
      setAlertText("");
      setSubmitDisabled(true);
      setFilteringText("");
      return;
    }

    navigate("/NIHR", {
      state: { HomeStateGrant: selectedItems[0], HomeStateUuid: runUUID },
    });
  };
  function sortGrantField(detail) {
    console.log("sortGrantField " + JSON.stringify(detail));
    if (detail.sortingColumn.id === "Release_Date") {
      if (!sortDescending) {
        setGrants(
          grants.sort((a, b) => {
            return new Date(b.Release_Date) - new Date(a.Release_Date); // ascending
          })
        );
        setSortDescending(true);
      } else {
        setGrants(
          grants.sort((a, b) => {
            return new Date(a.Release_Date) - new Date(b.Release_Date); // descending
          })
        );
        setSortDescending(false);
      }

      if (!sortDescending) {
        setGrants(
          grants.sort((a, b) => {
            return new Date(b.Release_Date) - new Date(a.Release_Date); // ascending
          })
        );
        setSortDescending(true);
      } else {
        setGrants(
          grants.sort((a, b) => {
            return new Date(a.Release_Date) - new Date(b.Release_Date); // descending
          })
        );
        setSortDescending(false);
      }
    } else if (detail.sortingColumn.id === "Expired_Date") {
      if (!sortDescending) {
        setGrants(
          grants.sort((a, b) => {
            return new Date(b.Expired_Date) - new Date(a.Expired_Date); // ascending
          })
        );
        setSortDescending(true);
      } else {
        setGrants(
          grants.sort((a, b) => {
            return new Date(a.Expired_Date) - new Date(b.Expired_Date); // descending
          })
        );
        setSortDescending(false);
      }
    } else if (detail.sortingColumn.id === "Clinical_Trials") {
      if (!sortDescending) {
        setGrants(
          grants.sort((a, b) => {
            return a.Clinical_Trials.toLowerCase() >
              b.Clinical_Trials.toLowerCase()
              ? -1
              : 1; // ascending
          })
        );
        setSortDescending(true);
      } else {
        setGrants(
          grants.sort((a, b) => {
            return a.Clinical_Trials.toLowerCase() <
              b.Clinical_Trials.toLowerCase()
              ? -1
              : 1; // descending
          })
        );
        setSortDescending(false);
      }
    }
  }

  async function scrapeNIHGrantURL(grant, _runUUID) {
    console.log("scrapeNIHGrantURL runUUID " + _runUUID);
    console.log("Bearer {accessToken} ");
    const ak = nihdata.ak
    try {
      const restOperation = post({
        apiName: "nihGrantsApi",

        path: "/scrapeURLContext",
        headers: {
          Authorization: accessToken,
          "Content-Type": "application/json",
          'x-api-key': ak.toString()
        },

        options: {
          queryParams: {
            runUUID: _runUUID,
            baseurl: grant.URL,
            contextFile: "NIH_Grant_Description",
            htmlObject: "div",
            htmlObjectAttribute: "data-section-code",
            htmlObjectAttributeValue: "FOD",
          },
        },
      });

      const { body } = await restOperation.response;
      const json = await body.json();
      console.log("result " + json);

      if (json.includes("Exception")) {
        setAlertType("error");
        setAlertVisible(true);
        setAlertText(JSON.stringify(json));
        setSubmitDisabled(false);
        return;
      } else {
        setAlertVisible(true);
        setAlertType("success");
        setAlertText("Your grant has been selected and the context added.");
        return;
      }
    } catch (e) {
      console.log("GET call for /scrapeURLContext failed: ", JSON.stringify(e));
      setAlertType("error");
      setAlertVisible(true);
      setAlertText(e.$metadata.httpStatusCode + " " + e.name);
      setSubmitDisabled(false);
    }
  }

  async function searchNIHGrants() {
    console.log("searchNIHGrants accessToken " + JSON.stringify(accessToken));
    const ak = nihdata.ak;
    try {
      const restOperation = post({
        apiName: "nihGrantsApi",
        path: "/search",

        options: {
          queryParams: {
            searchtext: filteringText,
          },
          headers: {
            Authorization: accessToken,
            "Content-Type": "application/json",
          },
        },
      });

      const { body } = await restOperation.response;
      console.log("body " + body);
      console.log("GET call for /Search succeeded");
      // consume as a string:
      //const str = await body.text();
      // OR consume as a blob:
      //const blob = await body.blob();
      // OR consume as a JSON:

      const json = await body.json();
      //console.log("GET Response " + JSON.stringify(json.hits.hits));
      if (json.hits === undefined) {
        setAlertType("error");
        setAlertVisible(true);
        setIsSpinning("inverted");
        setAlertText(
          "Exception thrown OpenSearch Index error - have the Available Grants been uploaded?"
        );
        setSubmitDisabled(true);
        return;
      }
      if (json.hits.hits.length === 0) {
        setAlertType("error");
        setAlertVisible(true);
        setAlertText("No results found for this search text");
        setSubmitDisabled(true);
        setIsSpinning("inverted");
        return;
      }
      setIsSpinning("inverted");

      let grantsArr = [];

      for (let i = 0; i < json.hits.hits.length; i++) {
        // TODO: hack to remove the special characters in Title
        //grantsArr[i] = json.hits.hits[i]._source;

        grantsArr[i] = {
          Title:
            json.hits.hits[i]._source[
              Object.keys(json.hits.hits[i]._source)[0]
            ],
          Release_Date:
            json.hits.hits[i]._source[
              Object.keys(json.hits.hits[i]._source)[1]
            ],
          Expired_Date:
            json.hits.hits[i]._source[
              Object.keys(json.hits.hits[i]._source)[2]
            ],
          Activity_Code:
            json.hits.hits[i]._source[
              Object.keys(json.hits.hits[i]._source)[3]
            ],

          Organization:
            json.hits.hits[i]._source[
              Object.keys(json.hits.hits[i]._source)[4]
            ],
          Parent_Organization:
            json.hits.hits[i]._source[
              Object.keys(json.hits.hits[i]._source)[5]
            ],
          Participating_Orgs:
            json.hits.hits[i]._source[
              Object.keys(json.hits.hits[i]._source)[6]
            ],
          Document_Number:
            json.hits.hits[i]._source[
              Object.keys(json.hits.hits[i]._source)[7]
            ],
          Document_Type:
            json.hits.hits[i]._source[
              Object.keys(json.hits.hits[i]._source)[8]
            ],
          Clinical_Trials:
            json.hits.hits[i]._source[
              Object.keys(json.hits.hits[i]._source)[9]
            ],
          URL: json.hits.hits[i]._source[
            Object.keys(json.hits.hits[i]._source)[10]
          ],
        };

        //console.log(grantsArr[i]);
      }

      setGrants(grantsArr);
    } catch (e) {
      console.log("GET call for /Search failed: ", e);
    }
  }

  return (
    <div className="search">
      <Container
        header={
          <Header
            actions={
              <SpaceBetween direction="horizontal" textAlign="center" size="m">
                <TextFilter
                  filteringText={filteringText}
                  filteringPlaceholder="Search NIH grants"
                  filteringAriaLabel="Filter instances"
                  onChange={({ detail }) =>
                    filteringTextChange(detail.filteringText)
                  }
                />
                <Button
                  variant="primary"
                  disabled={submitDisabled}
                  onClick={(event) => submitSearch(event)}
                >
                  Submit Search
                </Button>
                <Button
                  variant="secondary"
                  onClick={(event) => clearSearchText(event)}
                >
                  Clear search filter
                </Button>
                <Spinner size="large" variant={isSpinning} />
              </SpaceBetween>
            }
          >
            Search NIH Funding Opportunity Announcements
          </Header>
        }
      ></Container>

      <div className="searchr">
        <Container>
          <Table
            variant="borderless"
            onSelectionChange={({ detail }) => {
              console.log(detail.selectedItems);
              setSelectedItems(detail.selectedItems);
              setContextButtonDisabled(false);
            }}
            selectedItems={selectedItems}
            ariaLabels={{
              selectionGroupLabel: "Items selection",
              allItemsSelectionLabel: ({ selectedItems }) =>
                `${selectedItems.length} ${
                  selectedItems.length === 1 ? "item" : "items"
                } selected`,
              itemSelectionLabel: ({ selectedItems }, item) => item.Title,
            }}
            columnDefinitions={[
              {
                id: "Title",
                header: "Title",
                cell: (e) => e.Title,
                //sortingField: "Title",
                width: 350,
                isRowHeader: true,
              },
              {
                id: "Activity_Code",
                header: "Activity Code",
                cell: (e) => e.Activity_Code,
              },
              {
                id: "Release_Date",
                header: "Release Date",
                cell: (e) => e.Release_Date,
                sortingField: "Release_Date",
              },
              {
                id: "Expired_Date",
                header: "Expired Date",
                cell: (e) => e.Expired_Date,
                sortingField: "Expired_Date",
              },
              {
                id: "URL",
                header: "URL",
                cell: (e) => (
                  <Link external href={e.URL}>
                    Overview
                  </Link>
                ),
              },
              {
                id: "Organization",
                header: "Organization",
                cell: (e) => e.Organization,
              },

              {
                id: "Parent_Organization",
                header: "Parent_Organization",
                cell: (e) => e.Parent_Organization,
              },
              {
                id: "Document_Number",
                header: "Document Number",
                cell: (e) => e.Document_Number,
              },
              {
                id: "Clinical_Trials",
                header: "Clinical Trials",
                cell: (e) => e.Clinical_Trials,
                sortingField: "Clinical_Trials",
              },
            ]}
            items={getCurrentPageItems()}
            loadingText="Loading resources"
            resizableColumns
            wrapLines
            selectionType="single"
            onSortingChange={({ detail }) => {
              sortGrantField(detail);
            }}
            empty={
              <Box
                margin={{ vertical: "xs" }}
                textAlign="center"
                color="inherit"
              >
                <b>No matches for Search text</b>
              </Box>
            }
            pagination={
              <Pagination
                currentPageIndex={currentPageIndex}
                onChange={({ detail }) =>
                  setCurrentPageIndex(detail.currentPageIndex)
                }
                pagesCount={pagesCount}
                ariaLabels={{
                  nextPageLabel: "Next page",
                  previousPageLabel: "Previous page",
                  pageLabel: (pageNumber) =>
                    `Page ${pageNumber} of search results`,
                }}
              />
            }
          />
        </Container>
      </div>

      <Container>
        <SpaceBetween size="s">
          <Button
            onClick={(event) => collectURLContext(event)}
            disabled={contextButtonDisabled}
            variant="primary"
          >
            Use this Grant Opportunity to generate an NIH Grant Template{" "}
          </Button>
          <TextContent></TextContent>
          <Alert
            visible={alertVisible}
            action={
              <Button onClick={(event) => nextNavigation(event)}>OK</Button>
            }
            statusIconAriaLabel="Success"
            type={alertType}
          >
            {" "}
            {alertText}
          </Alert>
        </SpaceBetween>
      </Container>
    </div>
  );
};

const SideHelp = () => (
  <div className="help">
    <HelpPanel header={<h2>Search Available Grants</h2>}>
      <SpaceBetween size="m">
        <TextContent>
          As the largest public funder of biomedical research in the world, NIH
          supports a variety of programs from grants and contracts to loan
          repayment.
        </TextContent>
        <TextContent>
          This screen allows users to search for Grants that are available at
          the below link. The requirments from these grants will be used by the
          LLM to generate content.
        </TextContent>
        <Link
          external
          href="https://grants.nih.gov/funding/nih-guide-for-grants-and-contracts"
        >
          NIH Grants Search Page
        </Link>
      </SpaceBetween>
      <hr />
      <SpaceBetween size="m">
        <TextContent>
          In the search box, enter text for a topic of interest (e.g. Cancer,
          Alzheimer's, ...) or a Document Number or Activity Code or anything of
          interest.
        </TextContent>
        <TextContent>
          When you find the grant that you want to use for context in the LLM
          prompt, select it by clicking in the circle next to the grant
          opportunity. Then scroll down and select{" "}
          <strong>
            "Use this Grant Opportunity to generate an NIH Grant Template"
          </strong>
          . That will upload the Grant Abstract to S3 and move you to the next
          Screen once you click the Green OK button.
        </TextContent>
      </SpaceBetween>
    </HelpPanel>
  </div>
);

function Home({ signOut, user }) {
  const location = useLocation();

  const [lnavopen, setLnavopen] = useState(true);
  const [rnavopen, setRnavopen] = useState(false);

  const navChange = (detail) => {
    setLnavopen(detail.open);
  };
  const toolsChange = (detail) => {
    setRnavopen(detail.open);
  };

  return (
    <Authenticator signUpAttributes={["email"]}>
      {({ signOut, user }) => (
        <AppLayout
          disableContentPaddings={false}
          navigation={<Navigation user={user} path="1" />}
          content={<Content />}
          contentType="default"
          toolsOpen={rnavopen}
          toolsWidth={300}
          tools={<SideHelp />}
          navigationOpen={lnavopen}
          onNavigationChange={({ detail }) => navChange(detail)}
          onToolsChange={({ detail }) => toolsChange(detail)}
        />
      )}
    </Authenticator>
  );
}

export default Home;
