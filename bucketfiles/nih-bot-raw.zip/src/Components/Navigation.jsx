import {
  SideNavigation,
  SpaceBetween,
  TextContent,
  Link,
  Header,
  Box,
  Badge,
  Container,
  ButtonDropdown,
  Pagination,
} from "@cloudscape-design/components";
import "./Navigation.css";
import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";

const Navigation = (current_user) => {
  console.log("current_user " + JSON.stringify(current_user));
  console.log("current_user path " + JSON.stringify(current_user.user.path));
  const navigate = useNavigate();
  const User = current_user.User;
  const [researchName, setResearchName] = React.useState("");
  const [currentSelection, setCurrentSelection] = React.useState(current_user.user.path);
  const [badgeColor, setBadgeColor] = React.useState("#f47321");
  const [NavigationItems, setNavigationItems] = useState([]);
  
  const setResearchEnv = (event) => {
    console.log("event.detail " + JSON.stringify(event.detail));
    console.log("event.detail.id " + event.detail.id);
    console.log("researchName "+researchName);
    console.log("--------------------------");
    if (event.detail.id === "1") {
      navigate("/Home");
    } else if (event.detail.id === "2")  {
      navigate("/UploadGeneric");
    }
    setNavBar(event.detail.id);
  };

  const setNavBar = (id) => {
    console.log(" setNavBar id " + id);
    let navigation_items = [];
    if (id === "1" || id === ""  || id == null || id === undefined) {
      console.log("NIH Research nav path");
      setResearchName("NIH Research");

      navigation_items.push({
        type: "section",
        text: <strong style={{ color: "white" }}>Current User</strong>,
        defaultExpanded: false,
        items: [
          {
            type: "link",
            text: "username " + current_user.user.username,
            href: "#",
          },
          {
            type: "link",
            text: "Admin ",
            href: "/Admin",
          },
        ],
      });

      navigation_items.push({
        type: "section",
        text: <strong style={{ color: "white" }}>NIH Grant Search</strong>,
        defaultExpanded: true,
        items: [{ type: "link", text: "Search", href: "/Home" }],
      });

      navigation_items.push({
        type: "section",
        text: <strong style={{ color: "white" }}>NIH Reporter API</strong>,
        defaultExpanded: false,
        items: [{ type: "link", text: "Add to Context", href: "/NIHR" }],
      });

      navigation_items.push({
        type: "section",
        text: <strong style={{ color: "white" }}>AIMs Document Upload</strong>,
        defaultExpanded: false,
        expanded: true,
        items: [{ type: "link", text: "Add to Context", href: "/AIMsUpload" }],
      });

      navigation_items.push({
        type: "section",
        text: <strong style={{ color: "white" }}>Document Upload</strong>,
        defaultExpanded: false,
        expanded: true,
        items: [{ type: "link", text: "Add to Context", href: "/Upload" }],
      });
      navigation_items.push({
        type: "section",
        text: <strong style={{ color: "white" }}>Grant Generation</strong>,
        defaultExpanded: false,
        items: [{ type: "link", text: "Generate", href: "/TemplateGen" }],
      });

      setNavigationItems(navigation_items);
    } else {
      console.log("Generic Recommendation  path");
      setResearchName("Generic Research");
      navigation_items.push({
        type: "section",
        text: <strong style={{ color: "white" }}>Document Upload</strong>,
        defaultExpanded: false,
        expanded: true,
        items: [{ type: "link", text: "Add Documents to Context", href: "/UploadGeneric" }],
      });
      navigation_items.push({
        type: "section",
        text: <strong style={{ color: "white" }}>Content Generation</strong>,
        defaultExpanded: false,
        items: [{ type: "link", text: "Generate From Prompt", href: "/TemplateGenGeneric" }],
      });
      

      setNavigationItems(navigation_items);
    }
  };

  useEffect(() => {
    setNavBar(currentSelection);
  }, []);

  return (
    <div className="navigation">
      <SpaceBetween direction="vertical" size="s">
        <center>
          <img
            className="awsui-util-hide-in-dark-mode"
            src="/aws-samples-img.png"
            height="55%"
            width="60%"
            alt="NIH Logo"
          />
        </center>

        <center>
          <ButtonDropdown
            onItemClick={(event) => setResearchEnv(event)}
            items={[
              { text: "NIH Research", id: "1", disabled: false },
              { text: "Generic Prompt", id: "2", disabled: false }
            ]}
          >
            Select Research Path
          </ButtonDropdown>
        </center>

        <Box textAlign="center" color="inherit">
          <Badge color={badgeColor}>{researchName}</Badge>
        </Box>

        <SideNavigation items={NavigationItems} activeHref={0} />
      </SpaceBetween>
    </div>
  );
};

export default Navigation;
