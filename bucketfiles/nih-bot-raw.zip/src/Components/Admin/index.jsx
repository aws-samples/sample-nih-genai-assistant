import React, { useState, useEffect } from "react";
import "./index.css";
import { get, post } from "aws-amplify/api";
import {
  withAuthenticator,
} from "@aws-amplify/ui-react";
import "@aws-amplify/ui-react/styles.css";
import { fetchAuthSession } from '@aws-amplify/auth';
import {
  AppLayout,
  HelpPanel,
  Form,
  ColumnLayout,
  SpaceBetween,
  Button,
  Input,
  Header,
  Textarea,
  Table,
  Box,
  TextFilter,
  Pagination,
  Container,
  TextContent,
} from "@cloudscape-design/components";

import Navigation from "../Navigation";
import { useNavigate, useLocation } from "react-router-dom";
import { nihdata } from "../../nihdata";

const Content = () => {
  const [accessToken, setAccessToken] = useState(null);
  useEffect(() => {
    async function getTokens() {
      try {
        const session = await fetchAuthSession(); // Fetch the authentication session
        //console.log('Access Token:', session.tokens.accessToken.toString());
        setAccessToken(session.tokens.idToken.toString());
        //console.log('ID Token:', session.tokens.idToken.toString());
          const ak = nihdata.ak;
          const restOperation = post({
            //apiName: "nihapi",
            apiName: "nihGrantsApi",
    
            path: "/modelPrompts",
            headers: {
              Authorization: session.tokens.idToken.toString(),
              'Content-Type': 'application/json',
              'x-api-key': ak.toString()
            },
    
            options: {
              queryParams: {},
              headers: {
                Authorization: session.tokens.idToken.toString(),
                'Content-Type': 'application/json'
              },
            },
          });
    
          const { body } = await restOperation.response;
          console.log("GET call for /prompt succeeded");
    
          const json = await body.json();
    
          //console.log("GET Response " + JSON.stringify(json));
          setItems(json);
          setIsReady(true);
     
      } catch (error) {
        console.error("Error fetching tokens:", error);
      }
    }
    getTokens();
    //retrievePrompts();
  }, []);

  const navigate = useNavigate();
  const [items, setItems] = React.useState([]);
  const [promptValue, setPromptValue] = React.useState("");
  const [temperatureValue, setTemperatureValue] = React.useState();
  const [templateValue, setTemplateValue] = React.useState("");
  const [toppValue, setToppValue] = React.useState();
  const [selectedItems, setSelectedItems] = React.useState([]);
  const [isReady, setIsReady] = React.useState(false);
  const [submitDisabled, setSsubmitDisabled] = React.useState(true);
  const formSearch = (params) => {
    console.log("formSearch");
  };

  const nextNavigation = (event) => {
    console.log("nextNavigation ");

    navigate("/Home", {
      state: {},
    });
  };
  const submitToDDB = (event) => {
    console.log("submitToDDB ");
  };

  /*
  async function retrievePrompts() {
    try {
      const restOperation = post({
        //apiName: "nihapi",
        apiName: "nihGrantsApi",

        path: "/modelPrompts",

        options: {
          queryParams: {},
        },
      });

      const { body } = await restOperation.response;
      console.log("GET call for /prompt succeeded");

      const json = await body.json();

      //console.log("GET Response " + JSON.stringify(json));
      setItems(json);
      setIsReady(true);
    } catch (e) {
      console.log("GET call for /Search failed: ", e);
    }
  }
    */
  const onPromptSelection = (detail) => {
    console.log("onPromptSelection " + JSON.stringify(detail.selectedItems));
    setSelectedItems(detail.selectedItems);
    console.log(detail.selectedItems[0].prompt);
    setPromptValue(detail.selectedItems[0].prompt);
    setTemperatureValue(detail.selectedItems[0].temperature);
    setTemplateValue(detail.selectedItems[0].template);
    setToppValue(detail.selectedItems[0].top_p);
  };

  console.log("rendering selectedItems " + JSON.stringify(promptValue));
  if (!isReady) {
    return <div>Loading...</div>;
  } else {
    return (
      <div className="search">
        <Container>
          <TextContent>
            <h2>LLM Prompts</h2>
          </TextContent>
          <Table
            onSelectionChange={({ detail }) => onPromptSelection(detail)}
            selectedItems={selectedItems}
            ariaLabels={{
              selectionGroupLabel: "Items selection",
              allItemsSelectionLabel: ({ selectedItems }) =>
                `${selectedItems.length} ${
                  selectedItems.length === 1 ? "item" : "items"
                } selected`,
              itemSelectionLabel: ({ selectedItems }, item) => item.template,
            }}
            columnDefinitions={[
              {
                id: "template",
                header: "Template",
                cell: (e) => e.template,
                sortingField: "template",
                isRowHeader: true,
              },

              { id: "top_p", header: "top_p", cell: (e) => e.top_p },
              {
                id: "temperature",
                header: "Temperature",
                cell: (e) => e.temperature,
              },
            ]}
            enableKeyboardNavigation
            items={items}
            selectionType="single"
            loadingText="Loading resources"
            empty={
              <Box
                margin={{ vertical: "xs" }}
                textAlign="center"
                color="inherit"
              >
                <SpaceBetween size="m">
                  <b>No resources</b>
                  <Button>Create resource</Button>
                </SpaceBetween>
              </Box>
            }
            pagination={<Pagination currentPageIndex={1} pagesCount={1} />}
          />
        </Container>
        <Container header={<Header variant="h2">{templateValue}</Header>}>
          <SpaceBetween direction="vertical" size="l">
            <Container header={<Header variant="h6">Prompt</Header>}>
              <Textarea
                spellcheck
                rows="15"
                label="Prompt"
                onChange={({ detail }) => setPromptValue(detail.value)}
                value={promptValue}
                placeholder="model prompt"
                readOnly
              />
            </Container>
            <Container header={<Header variant="h6">Temperature</Header>}>
              <Input
                ariaLabel="Temperature"
                onChange={({ detail }) => setTemperatureValue(detail.value)}
                value={temperatureValue}
                placeholder="temperature"
              />
            </Container>
            <Container header={<Header variant="h6">top_p</Header>}>
              <Input
                label="top_p"
                onChange={({ detail }) => setToppValue(detail.value)}
                value={toppValue}
                placeholder="top_p value"
              />
            </Container>
            <ColumnLayout columns={2}>
              <SpaceBetween direction="horizontal" size="l">
                <Button
                  variant="secondary"
                  onClick={(event) => nextNavigation(event)}
                >
                  Home
                </Button>
                <Button
                  variant="primary"
                  disabled={submitDisabled}
                  onClick={(event) => submitToDDB(event)}
                >
                  Submit Changes
                </Button>
              </SpaceBetween>
            </ColumnLayout>
          </SpaceBetween>
        </Container>
      </div>
    );
  }
};

const SideHelp = () => (
  <div className="help">
    <HelpPanel header={<h2>Prompts</h2>}>
      <SpaceBetween size="m">
        <TextContent>
          This Screen allows you to view the LLM prompts and context
          placeholders for both AIMs generation and for full Grant Proposal
          Generation.
        </TextContent>
        <TextContent>
          Currently this is in a read only mode but future releases will allow
          for users to modify the prompts.
        </TextContent>
      </SpaceBetween>
    </HelpPanel>
  </div>
);

function Admin({ signOut, user }) {
  const location = useLocation();
  console.log("Home location " + JSON.stringify(location));

  useEffect(() => {}, []);

  const [lnavopen, setLnavopen] = useState(true);
  const [rnavopen, setRnavopen] = useState(false);

  const navChange = (detail) => {
    setLnavopen(detail.open);
  };
  const toolsChange = (detail) => {
    setRnavopen(detail.open);
  };

  return (
    <AppLayout
      disableContentPaddings={false}
      navigation={<Navigation user={user} />}
      content={<Content />}
      contentType="default"
      toolsOpen={rnavopen}
      toolsWidth={300}
      tools={<SideHelp />}
      navigationOpen={lnavopen}
      onNavigationChange={({ detail }) => navChange(detail)}
      onToolsChange={({ detail }) => toolsChange(detail)}
    />
  );
}

export default withAuthenticator(Admin);
