import React, { useState, useEffect } from "react";
import "./index.css";
import { post } from "aws-amplify/api";
import { withAuthenticator } from "@aws-amplify/ui-react";
import "@aws-amplify/ui-react/styles.css";
import { fetchAuthSession } from "@aws-amplify/auth";
import {
  AppLayout,
  HelpPanel,
  Table,
  Box,
  SpaceBetween,
  Button,
  TextFilter,
  Header,
  Pagination,
  Container,
  Alert,
  TextContent,
  Link,
  Spinner,
} from "@cloudscape-design/components";
import { ExpandableSection } from "@cloudscape-design/components";

import Navigation from "../Navigation";
import { useNavigate, useLocation } from "react-router-dom";
import { Amplify } from "aws-amplify";
import awsconfig from "../../aws-exports";
import { uploadData } from "aws-amplify/storage";
import { nihdata } from "../../nihdata";

Amplify.configure(awsconfig, {
  Storage: {
    S3: {
      prefixResolver: async ({ accessLevel, targetIdentityId }) => {
        if (accessLevel === "guest") {
          return "artifacts/";
        } else if (accessLevel === "protected") {
          return `artifacts//${targetIdentityId}/`;
        } else {
          return `artifacts//${targetIdentityId}/`;
        }
      },
    },
  },
});

const Content = () => {
  const [runUUID, setRunUUID] = useState(() => {
    console.log("GETTING LOCAL STORAGE");
    const savedItem = localStorage.getItem("runUUID");
    const parsedItem = JSON.parse(savedItem);
    console.log("GETTING LOCAL STORAGE " + parsedItem);
    return parsedItem || "";
  });
  const [accessToken, setAccessToken] = useState(null);
  const [isSpinning, setIsSpinning] = React.useState("inverted");

  useEffect(() => {
    async function getTokens() {
      try {
        const session = await fetchAuthSession(); // Fetch the authentication session
        //console.log('Access Token:', session.tokens.accessToken.toString());
        setAccessToken(session.tokens.idToken.toString());
        //console.log('ID Token:', session.tokens.idToken.toString());
      } catch (error) {
        console.error("Error fetching tokens:", error);
      }
    }
    getTokens();
  }, []);

  const [filteringText, setFilteringText] = React.useState("");
  const [alertType, setAlertType] = React.useState("success");
  const [alertText, setAlertText] = React.useState(
    "The awarded grant has been selected and the context added."
  );
  const [alertVisible, setAlertVisible] = React.useState(false);
  const [grants, setGrants] = React.useState([]);
  const [selectedItems, setSelectedItems] = React.useState([{ Title: "" }]);
  const [submitDisabled, setSubmitDisabled] = React.useState(true);
  const [contextButtonDisabled, setContextButtonDisabled] =
    React.useState(true);
  const [sortDescending, setSortDescending] = React.useState(false);
  const navigate = useNavigate();
  const [currentPageIndex, setCurrentPageIndex] = useState(1);
  const itemsPerPage = 25;
  const pagesCount = Math.ceil(grants.length / itemsPerPage);
  const filteringTextChange = (detail) => {
    setFilteringText(detail);
    setSubmitDisabled(false);
  };
  // Get current page items
  const getCurrentPageItems = () => {
    const startIndex = (currentPageIndex - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return grants.slice(startIndex, endIndex);
  };
  const clearSearchText = (event) => {
    console.log("clearSearchText");
    setSubmitDisabled(true);
    setAlertText("");
    setContextButtonDisabled(true);
    setIsSpinning("inverted");
    setFilteringText("");

    setAlertVisible(false);
    setGrants([]);
  };
  const submitSearch = (params) => {
    console.log("submitSearch " + JSON.stringify(params));
    setIsSpinning("normal");
    if (filteringText.length <= 4) {
      setAlertVisible(true);
      setAlertType("error");
      setAlertText("Please enter a search term longer than 4 characters.");
      setIsSpinning("inverted");
      return;
    }
    searchNIHGrants();
  };

  const skipContext = () => {
    console.log("");
    navigate("/AIMsUpload", {});
  };

  const collectAbstractContext = async (event) => {
    // collect Document Content
    setSubmitDisabled(true);
    setAlertText("The awarded grant has been selected and the context added.");
    console.log(
      "selectedItems " + JSON.stringify(selectedItems[0].abstract_text)
    );
    //var fileBits = str2ab(selectedItems[0].abstract_text.toString());
    var fileObj = new File(
      [selectedItems[0].abstract_text],
      selectedItems[0].name
    );

    try {
      const result = await uploadData({
        key: "nih-reporter/" + runUUID + "/" + selectedItems[0].name,
        data: fileObj,
        //bucket: "nih-grants-bucket",
        options: {
          onProgress: ({ transferredBytes, totalBytes }) => {
            if (totalBytes) {
              console.log(
                `Upload progress ${
                  Math.round(transferredBytes / totalBytes) * 100
                } %`
              );
              //setProgressBarValue((transferredBytes / totalBytes) * 100);
            }
          },
        },
      }).result;

      console.log("Succeeded: ", result);
      setAlertVisible(true);
      setAlertType("success");
      //setSubmitDisabled(false);
    } catch (e) {
      console.log("Error : ", e);
      setAlertVisible(true);
      setAlertType("error");
      //setProgressStatus("status");
      setSubmitDisabled(false);
      setAlertText(e.$metadata.httpStatusCode + " " + e.name);
    }
  };
  const nextNavigation = () => {
    navigate("/AIMsUpload", {});
  };
  function sortReleaseDate(detail) {
    if (!sortDescending) {
      setGrants(
        grants.sort((a, b) => {
          return new Date(b.award_notice_date) - new Date(a.award_notice_date); // ascending
        })
      );
      setSortDescending(true);
    } else {
      setGrants(
        grants.sort((a, b) => {
          return new Date(a.award_notice_date) - new Date(b.award_notice_date); // descending
        })
      );
      setSortDescending(false);
    }
  }

  async function searchNIHGrants() {
    console.log("searchNIHGrants  " + filteringText);
    console.log("searchNIHGrants  " + accessToken);
    const ak = nihdata.ak;
    try {
      const restOperation = post({
        apiName: "nihGrantsApi",
        path: "/nihrSearch",
        headers: {
          Authorization: accessToken,
          "Content-Type": "application/json",
          'x-api-key': ak.toString()
        },
        options: {
          headers: {
            Accept: "application/json",
            Authorization: accessToken,
          },
          body: {
            criteria: {
              advanced_text_search: {
                operator: "and",
                search_field:
                  "projecttitle,terms,abstracttext,opportunitynumber",
                search_text: filteringText,
              },
              date_added: { from_date: "2014-01-01", to_date: "2024-01-30" },
            },
            offset: 0,
            limit: 50,
            sort_field: "appl_id",
            sort_order: "desc",
          },
        },
      });

      const { body } = await restOperation.response;
      console.log("POST call succeeded");

      const json = await body.json();

      let grantsArr = [];

      for (let i = 0; i < json.results.length; i++) {
        // TODO: hack to remove the special characters in Title
        //grantsArr[i] = json.hits.hits[i]._source;

        console.log(json.results[i].project_title);
        // check if json.results[i] has null values
        if (json.results[i].project_title == null) {
          json.results[i].project_title = "";
        }
        if (json.results[i].abstract_text == null) {
          json.results[i].abstract_text = "";
        }
        if (json.results[i].opportunity_number == null) {
          json.results[i].opportunity_number = "";
        }
        if (json.results[i].full_study_section == null) {
          json.results[i].full_study_section = { name: "", url: "" };
        }
        if (json.results[i].full_study_section.name == null) {
          json.results[i].full_study_section.name = "";
        }
        if (json.results[i].full_study_section.url == null) {
          json.results[i].full_study_section.url = "";
        }
        if (json.results[i].award_amount == null) {
          json.results[i].award_amount = "";
        }
        if (json.results[i].award_notice_date == null) {
          json.results[i].award_notice_date = "";
        }
        if (json.results[i].dept_type == null) {
          json.results[i].dept_type = "";
        }
        if (json.results[i].project_num == null) {
          json.results[i].project_num = "";
        }
        if (json.results[i].org_name == null) {
          json.results[i].org_name = "";
        }

        try {
          grantsArr[i] = {
            org_name: json.results[i].agency_code,
            award_notice_date: json.results[i].award_notice_date,
            award_amount: json.results[i].award_amount,
            dept_type: json.results[i].dept_type,
            project_num: json.results[i].project_num,
            name: json.results[i].full_study_section.name,
            url: json.results[i].full_study_section.url,
            abstract_text: json.results[i].abstract_text,
            opportunity_number: json.results[i].opportunity_number,
            project_title: json.results[i].project_title,
          };
        } catch (e) {
          console.log(e);
        }

        //console.log(grantsArr[i]);

        //
      }

      setGrants(grantsArr);
      setIsSpinning("inverted");
    } catch (e) {
      setIsSpinning("inverted");
      console.log("POST call failed: ", e);
    }
  }

  return (
    <div className="search">
      <Container
        fitHeight
        header={
          <Header
            actions={
              <SpaceBetween direction="horizontal" textAlign="center" size="m">
                <TextFilter
                  filteringText={filteringText}
                  filteringPlaceholder="Search NIH RePorter awarded grants"
                  filteringAriaLabel="Filter instances"
                  onChange={({ detail }) =>
                    filteringTextChange(detail.filteringText)
                  }
                />
                <Button
                  variant="primary"
                  disabled={submitDisabled}
                  onClick={(event) => submitSearch(event)}
                >
                  Submit Search
                </Button>
                <Button
                  variant="secondary"
                  onClick={(event) => clearSearchText(event)}
                >
                  Clear search filter
                </Button>
                <Button
                  variant="secondary"
                  onClick={(event) => skipContext(event)}
                >
                  Skip
                </Button>
                <Spinner size="large" variant={isSpinning} />
              </SpaceBetween>
            }
          >
            Search Awarded Grants
          </Header>
        }
      >
        <SpaceBetween direction="horizontal" textAlign="center" size="l">
          <Container fitHeight>
            <Table
              variant="borderless"
              resizableColumns
              onSelectionChange={({ detail }) => {
                console.log(detail.selectedItems);
                setSelectedItems(detail.selectedItems);
                setContextButtonDisabled(false);
              }}
              selectedItems={selectedItems}
              ariaLabels={{
                selectionGroupLabel: "Items selection",
                allItemsSelectionLabel: ({ selectedItems }) =>
                  `${selectedItems.length} ${
                    selectedItems.length === 1 ? "item" : "items"
                  } selected`,
                itemSelectionLabel: ({ selectedItems }, item) => item.Title,
              }}
              columnDefinitions={[
                {
                  id: "project_title",
                  header: "Project Title",
                  cell: (e) => e.project_title,
                  isRowHeader: true,
                  minWidth: 200
                },
                {
                  id: "opportunity_number",
                  header: "Opportunity Number",
                  cell: (e) => e.opportunity_number,
                  isRowHeader: true,
                  minWidth: 150
                },
                {
                  id: "award_notice_date",
                  header: "Award Date",
                  cell: (e) => e.award_notice_date,
                  sortingField: "award_notice_date",
                  //width: "350",
                  isRowHeader: true,
                  minWidth: 120
                },
                {
                  id: "abstract_text",
                  header: "Abstract",
                  cell: (item) => (
                    <ExpandableSection
                      variant="footer"
                      headerText={item.abstract_text.substring(0, 200) + "..."}
                    >
                      {item.abstract_text}
                    </ExpandableSection>
                  ),
                  minWidth: 400
                },
                {
                  id: "org_name",
                  header: "Organization",
                  cell: (e) => e.org_name,
                  //sortingField: "Title",
                  //width: "350",
                  isRowHeader: true,
                  minWidth: 150
                },
                {
                  id: "award_amount",
                  header: "Award Amount",
                  cell: (e) => "$" + e.award_amount,
                  //sortingField: "Release_Date",
                  minWidth: 120
                },
              ]}
              items={getCurrentPageItems()} // Changed from grants to getCurrentPageItems()
              loadingText="Loading resources"
              stripedRows
              contentDensity="compact"
              wrapLines
              selectionType="single"
              sortingColumn="award_notice_date"
              onSortingChange={({ detail }) => {
                sortReleaseDate(detail);
              }}
              empty={
                <Box
                  margin={{ vertical: "xs" }}
                  textAlign="center"
                  color="inherit"
                >
                  <b>No matches for Search text</b>
                </Box>
              }
              pagination={
                <Pagination
                  currentPageIndex={currentPageIndex}
                  onChange={({ detail }) =>
                    setCurrentPageIndex(detail.currentPageIndex)
                  }
                  pagesCount={pagesCount}
                  ariaLabels={{
                    nextPageLabel: "Next page",
                    previousPageLabel: "Previous page",
                    pageLabel: (pageNumber) => `Page ${pageNumber} of grants`,
                    paginationLabel: "Grants Reporter pagination",
                  }}
                />
              }
            />
          </Container>
        </SpaceBetween>
      </Container>

      <Container fitHeight>
        <SpaceBetween size="l">
          <Button
            onClick={(event) => collectAbstractContext(event)}
            disabled={contextButtonDisabled}
            variant="primary"
          >
            Use this Abstract as context to generate template{" "}
          </Button>
          <TextContent></TextContent>
          <Alert
            visible={alertVisible}
            action={
              <Button onClick={(event) => nextNavigation(event)}>OK</Button>
            }
            statusIconAriaLabel="Success"
            type={alertType}
          >
            {" "}
            {alertText}
          </Alert>
        </SpaceBetween>
      </Container>
    </div>
  );
};

const SideHelp = () => (
  <div className="help">
    <HelpPanel header={<h2>Search Awarded Grants</h2>}>
      <SpaceBetween size="m">
        <TextContent>
          Each award supported by NIH promotes efforts to seek fundamental
          knowledge about the nature and behavior of living systems and/or the
          application of that knowledge to enhance health, lengthen life, and
          reduce illness and disability.
        </TextContent>
        <TextContent>
          This screen allows users to search for Grants that have already been
          awarded at the below link. The abstracts from these grants will be
          used by the LLM to generate content.
        </TextContent>
        <Link external href="https://reporter.nih.gov/">
          NIH Reporter Search Page
        </Link>
      </SpaceBetween>
      <hr />
      <SpaceBetween size="m">
        <TextContent>
          In the search box, enter text for a topic of interest (e.g. Cancer,
          Alzheimer's, ...) or a Document Number or Activity Code or anything of
          interest.
        </TextContent>
        <TextContent>
          When you find the awarded grant that you want to use for context in
          the LLM prompt, select it by clicking in the circle next to the
          awarded grant. Then scroll down and select{" "}
          <strong>"Use this Abstract as context to generate template"</strong>.
          That will upload the Grant Abstract to S3 and move you to the next
          Screen once you click the Green OK button.
        </TextContent>
      </SpaceBetween>
      <hr />
      <SpaceBetween size="m">
        {" "}
        <TextContent>
          You can choose to skip this screen and can always go back to it in the
          left Navigation bar{" "}
        </TextContent>
      </SpaceBetween>
    </HelpPanel>
  </div>
);

function NIHR({ signOut, user }) {
  user.path = "1";
  console.log("NIHR " + JSON.stringify(user));
  const [lnavopen, setLnavopen] = useState(true);
  const [rnavopen, setRnavopen] = useState(false);

  const navChange = (detail) => {
    setLnavopen(detail.open);
  };
  const toolsChange = (detail) => {
    setRnavopen(detail.open);
  };

  return (
    <AppLayout
      disableContentPaddings={false}
      navigation={<Navigation user={user} />}
      content={<Content />}
      contentType="default"
      toolsOpen={rnavopen}
      toolsWidth={300}
      tools={<SideHelp />}
      navigationOpen={lnavopen}
      onNavigationChange={({ detail }) => navChange(detail)}
      onToolsChange={({ detail }) => toolsChange(detail)}
    />
  );
}

export default withAuthenticator(NIHR);
