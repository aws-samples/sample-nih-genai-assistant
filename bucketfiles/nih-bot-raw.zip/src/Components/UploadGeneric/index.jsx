import React, { useState, useEffect } from "react";
import "./index.css";
import { withAuthenticator } from "@aws-amplify/ui-react";
import "@aws-amplify/ui-react/styles.css";
import { appLayoutLabels } from "../labels";
import { SignatureV4 } from "@smithy/signature-v4";
import { HttpRequest } from "@smithy/protocol-http";
import { Sha256 } from "@aws-crypto/sha256-js";
import { fetchAuthSession } from "@aws-amplify/auth";
import {
  AppLayout,
  Box,
  Header,
  HelpPanel,
  Button,
  Form,
  Container,
  TextContent,
  FormField,
  FileUpload,
  ProgressBar,
  Spinner,
  SpaceBetween,
  Alert,
  Table,
  Pagination,
} from "@cloudscape-design/components";
import Navigation from "../Navigation";
import { Amplify } from "aws-amplify";
import awsconfig from "../../aws-exports";
import { uploadData } from "aws-amplify/storage";
import { useNavigate, useLocation } from "react-router-dom";
import { nihdata } from "../../nihdata";

Amplify.configure(awsconfig, {
  Storage: {
    S3: {
      prefixResolver: async ({ accessLevel, targetIdentityId }) => {
        if (accessLevel === "guest") {
          return "artifacts/";
        } else if (accessLevel === "protected") {
          return `artifacts/${targetIdentityId}/`;
        } else {
          return `artifacts/${targetIdentityId}/`;
        }
      },
    },
  },
});

var examplePrompt =
  "You are a clinician in critical care units and must understand how mechanical ventilation affects patient physiology and responses to various states. Start this task by carefully reviewing the content between the <docs> tags that follow <docs> {docs} </docs>. Using the reviewed information, provide a recommendation for this question. When ventilating a patient, using the ARDSnet peep and fio2 table, what changes to peep and fio2 would you suggest if peep is currently at 10 and fio2 is at 40 percent and the patient has an spo2 of 84 percent and a plateau pressure of 28? The recommendation should have three sections. The first section is a recap of the Current Patient Status. The second section is the Recommendation. The third section is the Rationale for the Recommendation. Create the recommendation content in HTML format for every section of the recommendation using HTML header Tags for main paragraphs and HTML ul tags for the main bullet points. ***  It is important that you must use the xml tags and placeholder of <docs> {docs} </docs> ***";

const Content = () => {
  const [runUUID, setRunUUID] = React.useState(uuidv4());

  useEffect(() => {
    localStorage.setItem("runUUID", JSON.stringify(runUUID));
    console.log("SETTING LOCAL STORAGE " + runUUID);
  }, [runUUID]);
 

  const [uploadedDocs, setUploadedDocs] = React.useState([]);
  const [value, setValue] = React.useState([]);
  const [progressBarValue, setProgressBarValue] = React.useState(0);
  const [isSpinning, setIsSpinning] = React.useState("inverted");
  const [progressStatus, setProgressStatus] = React.useState("success");
  const [submitDisabled, setSubmitDisabled] = React.useState(false);
  const [alertVisible, setAlertVisible] = React.useState(false);
  const [alertText, setAlertText] = React.useState("No files to upload");
  const [alertType, setAlertType] = React.useState("error");
  const [contextButtonDisabled, setContextButtonDisabled] =
    React.useState(true);

  const navigate = useNavigate();
  const collectDocumentContext = async () => {
    console.log("collectDocumentContext ");

    navigate("/TemplateGenGeneric", {});
  };

  const skipContext = () => {
    console.log("skipContext ");
    navigate("/TemplateGenGeneric", {});
  };
  const cancel = async (event) => {
    setUploadedDocs([]);
  };
  function addElement(newValue) {
    setUploadedDocs((prevUploadedDocs) => [...prevUploadedDocs, newValue]);
    return;
  }
  function uuidv4() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
      /[xy]/g,
      function (c) {
        const r = (Math.random() * 16) | 0,
          v = c === "x" ? r : (r & 0x3) | 0x8;
        return v.toString(16);
      }
    );
  }
  const generateWebSocketUrl = async () => {
      try {
        const session = await fetchAuthSession();
        const credentials = {
          accessKeyId: session.credentials.accessKeyId,
          secretAccessKey: session.credentials.secretAccessKey,
          sessionToken: session.credentials.sessionToken
        };
    
        // Verify credentials
        if (!credentials.accessKeyId || !credentials.secretAccessKey || !credentials.sessionToken) {
          throw new Error('Invalid credentials');
        }
    
        // Get the original URL and remove the trailing slash
        const cleanUrl = nihdata.wss;
        //const cleanUrl = originalUrl.replace(/\/+\$/, ''); // Remove trailing slashes
        
        console.log('Original WSS URL:', cleanUrl);
        console.log('Clean WSS URL:', cleanUrl);
    
        // Parse the cleaned WebSocket URL
        const endpoint = new URL(cleanUrl);
    
        // Extract region from hostname (format: <api-id>.execute-api.<region>.amazonaws.com)
        const hostnameComponents = endpoint.hostname.split('.');
        let region = 'us-east-1'; // Default fallback
        
        // Check if hostname follows expected pattern
        if (hostnameComponents.length >= 4 && 
            hostnameComponents[1] === 'execute-api' && 
            hostnameComponents[3] === 'amazonaws') {
          region = hostnameComponents[2];
        }
        
        console.log('Extracted region:', region);
    
        // Create the signer with the extracted region
        const signer = new SignatureV4({
          credentials: credentials,
          region: region,
          service: 'execute-api',
          sha256: Sha256
        });
    
        // Create the HTTP request object with the clean path
        const request = new HttpRequest({
          method: 'GET',
          protocol: endpoint.protocol,
          hostname: endpoint.hostname,
          path: endpoint.pathname,
          headers: {
            host: endpoint.hostname
          }
        });
    
        // Presign the request
        const presigned = await signer.presign(request, {
          expiresIn: 300 // 5 minutes
        });
    
        // Convert the presigned request to a WebSocket URL
        const queryParams = new URLSearchParams();
        Object.entries(presigned.query || {}).forEach(([key, value]) => {
          if (value !== undefined && value !== null) {
            queryParams.append(key, value);
          }
        });
    
        // Use the clean URL, not the original with trailing slash
        const wsUrl = `${cleanUrl}?${queryParams.toString()}`;
        console.log('Final WebSocket URL:', wsUrl);
        
        return wsUrl;
    
      } catch (error) {
        console.error('Error generating signed URL:', error);
        throw error;
      }
    };
      
  const submitForm = async (event) => {
    setAlertText("");
    setAlertText("");
    setContextButtonDisabled(true);
    if (value.length > 0) {
      setSubmitDisabled(true);
      setIsSpinning("normal");
      setProgressStatus("in-progress");
      console.log("json " + JSON.stringify(value));
      console.log("fileChanged " + value[0].name);
      console.log("length " + value.length);
      console.log("data " + value[0]);

      try {
        var pdfN = value[0].name.indexOf(".pdf");
        var txtN = value[0].name.indexOf(".txt");
        console.log("pdfN " + pdfN);
        console.log("txtN " + txtN);
        if (
          value[0].name.indexOf(".pdf") === -1 &&
          value[0].name.indexOf(".txt") === -1
        ) {
          alert("Only .txt or .pdf files allowed");
          setSubmitDisabled(false);
          return;
        } else {
          console.log("PDF or  TXT found");
        }

        var filenameStripped = value[0].name.replace(
          /[`~!@#$%^&*()_|+\-=?;:'",<>\{\}\[\]\\\/]/gi,
          ""
        );
        filenameStripped = filenameStripped.replace(/\s+/g, "-").toLowerCase();
        console.log("CHANGED FILE " + filenameStripped);

        const result = await uploadData({
          key: "customer-uploads/" + runUUID + "/" + filenameStripped,
          data: value[0],
          options: {
            onProgress: ({ transferredBytes, totalBytes }) => {
              if (totalBytes) {
                console.log(
                  `Upload progress ${
                    Math.round(transferredBytes / totalBytes) * 100
                  } %`
                );
                setProgressBarValue((transferredBytes / totalBytes) * 100);
              }
            },
          },
        }).result;

        console.log("Succeeded: ", result);

        if (value[0].name.indexOf(".pdf") !== -1) {
          setAlertType("warning");
          setAlertText(
            "PDF document is being converted to text, WAIT until complete before choosing another file"
          );
          setAlertVisible(true);
          const signedUrl = await generateWebSocketUrl();
          const socket = new WebSocket(signedUrl);

          socket.addEventListener("message", (event) => {
            console.log("Message from server ", event);
            var message = event.data;
            console.log(message);
            var jsonMessage = JSON.parse(message);
            console.log("jsonMessage " + jsonMessage.message);

            if (jsonMessage.message === "PDF Converted") {
              console.log("PDF Converted");
              setAlertText("PDF document successfully converted to text");
              setAlertVisible(true);
              setAlertType("success");

              setValue([]);
              setProgressStatus("success");
              setIsSpinning("inverted");
              //setSubmitDisabled(false);
              socket.close();
            }

            var filenameStripped = value[0].name.replace(
              /[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi,
              ""
            );
            console.log(filenameStripped);
            addElement({ fileName: filenameStripped });
            console.log("uploadedDocs " + uploadedDocs);
            setContextButtonDisabled(false);
          });
          // disconnect socket
          socket.addEventListener("close", (event) => {
            console.log("Socket closed ", event);

            if (!event.wasClean) {
              // This indicates an abnormal closure (connection lost, network error, etc.)
              setValue([]);
              setProgressStatus("error");
              setAlertVisible(true);
              setAlertText("You encountered a network error ");
              setSubmitDisabled(false);
          } else {
              // Normal closure
              setValue([]);
              setProgressStatus("success");
              setSubmitDisabled(false);
          }
          });
        } else {
          var filenameStripped = value[0].name.replace(
            /[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi,
            ""
          );
          console.log(filenameStripped);
          addElement({ fileName: filenameStripped });
          console.log("uploadedDocs " + uploadedDocs);
          setContextButtonDisabled(false);

          setValue([]);
          setProgressStatus("success");
          setIsSpinning("inverted");
          setSubmitDisabled(false);
        }

        //
        //
        //
      } catch (error) {
        console.log("Error : ", error);
        setProgressStatus("status");
        setSubmitDisabled(false);
        setAlertText(JSON.stringify(error));
        setAlertVisible(true);
        setContextButtonDisabled(false);
      }
    } else {
      console.log("No files to upload");
      setAlertText("No files to upload");
      setAlertVisible(true);
      setSubmitDisabled(false);
      setContextButtonDisabled(false);
      setAlertType("error");
    }
  };

  const fileChanged = (detail) => {
    setValue(detail.value);
    setAlertText("");
    setAlertVisible(false);
  };
  const dismissAlert = (event) => {
    setAlertVisible(false);
  };

  return (
    <div className="search">
      <Alert
        dismissible
        statusIconAriaLabel="Error"
        type={alertType}
        onDismiss={() => dismissAlert()}
        visible={alertVisible}
      >
        {alertText}
      </Alert>

      <Form
        actions={
          <SpaceBetween direction="horizontal" size="xs">
            <Button onClick={(event) => cancel(event)} variant="link">
              {" "}
              Cancel
            </Button>
            <Button
              disabled={submitDisabled}
              onClick={(event) => submitForm(event)}
              variant="primary"
            >
              Submit
            </Button>
            <Button
              disabled={submitDisabled}
              onClick={(event) => skipContext(event)}
              variant="primary"
            >
              Skip
            </Button>
          </SpaceBetween>
        }
      >
        <Container
         
        >
          <FormField
            label="Context Upload"
            description="Upload PDF or text files"
          >
            <FileUpload
              onChange={({ detail }) => fileChanged(detail)}
              value={value}
              fileErrors={[""]}
              i18nStrings={{
                uploadButtonText: (e) => (e ? "Choose files" : "Choose file"),
                dropzoneText: (e) =>
                  e ? "Drop files to upload" : "Drop file to upload",
                removeFileAriaLabel: (e) => `Remove file ${e + 1}`,
                limitShowFewer: "Show fewer files",
                limitShowMore: "Show more files",
                errorIconAriaLabel: "Error",
              }}
              showFileLastModified
              showFileSize
              showFileThumbnail
              tokenLimit={3}
              constraintText=""
            />
          </FormField>
           <Spinner size="large" variant={isSpinning} />
        </Container>
      </Form>
      <div className="progress">
        <ProgressBar
          value={progressBarValue}
          additionalInfo=""
          description=""
          status={progressStatus}
          label="Upload Progress"
        />
      </div>

      <TextContent></TextContent>
      <SpaceBetween size="l">
        <Table
          columnDefinitions={[
            {
              id: "fileName",
              header: "File Name",
              cell: (e) => e.fileName,
              sortingField: "fileName",
              isRowHeader: true,
            },
          ]}
          columnDisplay={[{ id: "fileName", visible: true }]}
          items={uploadedDocs}
          loadingText="Loading resources"
          empty={
            <Box margin={{ vertical: "xs" }} textAlign="center" color="inherit">
              <SpaceBetween size="m">
                <b>No resources</b>
              </SpaceBetween>
            </Box>
          }
          header={<Header>Uploaded Resources</Header>}
          pagination={<Pagination currentPageIndex={1} pagesCount={1} />}
        />
      </SpaceBetween>

      <Container fitHeight>
        <SpaceBetween size="l">
          <Button
            onClick={(event) => collectDocumentContext(event)}
            disabled={contextButtonDisabled}
            variant="primary"
          >
            Use these Documents as context in your prompt{" "}
          </Button>
          <TextContent></TextContent>
        </SpaceBetween>
      </Container>
    </div>
  );
};

const SideHelp = () => (
  <div className="help">
    <HelpPanel header={<h2>Customer Documents Context Uploads</h2>}>
      <SpaceBetween size="m">
        <TextContent>
          This is where you can add supporting documents that will help the LLM
          generate content. The contents of these documents can be used in the
          prompt to guide the LLM.
        </TextContent>
        <TextContent>
          An example prompt that uses the updloaded documents would like like
          this <br/>
          <strong>{examplePrompt}</strong>
        </TextContent>
       
        <TextContent>
          You don't have to upload any documents and can choose to let the LLM
          answer with the knowledge it already has.
        </TextContent>
        <hr />
        <SpaceBetween size="m">
          {" "}
          <TextContent>
            You can choose to skip this screen and can always go back to it in
            the left Navigation bar{" "}
          </TextContent>
          <hr />
        </SpaceBetween>
      </SpaceBetween>
    </HelpPanel>
  </div>
);

function UploadGeneric({ signOut, user }) {
  user.path= "2";
  console.log("UploadGeneric " + JSON.stringify(user));
  const [User, setUser] = useState(user);
  const [completedItems, setCompletedItems] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  if (process.env.NODE_ENV === "development")
    console.log("The Upload setup begins ---------->");

  useEffect(() => {
    if (process.env.NODE_ENV === "development")
      console.log("useEffect called .  .  ." + JSON.stringify(user));

    try {
      setUser(user);
      setIsLoading(false);
    } catch (e) {
      setIsLoading(false);
      if (process.env.NODE_ENV === "development")
        console.log(JSON.stringify(e));
    } finally {
      if (process.env.NODE_ENV === "development") console.log("finally");
    }
  }, [user]);
  if (process.env.NODE_ENV === "development") console.log("After useEffect ");

  const [lnavopen, setLnavopen] = useState(true);
  const [rnavopen, setRnavopen] = useState(false);

  const navChange = (detail) => {
    setLnavopen(detail.open);
  };
  const toolsChange = (detail) => {
    setRnavopen(detail.open);
  };

  if (!isLoading) {
    return (
      <AppLayout
        disableContentPaddings={false}
        navigation={<Navigation user={user} />}
        content={<Content />}
        contentType="default"
        tools={<SideHelp />}
        toolsOpen={rnavopen}
        toolsWidth={300}
        navigationOpen={lnavopen}
        onNavigationChange={({ detail }) => navChange(detail)}
        onToolsChange={({ detail }) => toolsChange(detail)}
        ariaLabels={appLayoutLabels}
      />
    );
  } else {
    return (
      <Container>
        <TextContent>Loading . . . </TextContent>
      </Container>
    );
  }
}

export default withAuthenticator(UploadGeneric);
