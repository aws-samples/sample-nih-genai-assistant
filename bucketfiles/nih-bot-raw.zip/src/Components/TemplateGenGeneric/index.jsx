import React, { useState, useEffect } from "react";
import "./index.css";
import { SignatureV4 } from "@smithy/signature-v4";
import { HttpRequest } from "@smithy/protocol-http";
import { Sha256 } from "@aws-crypto/sha256-js";
import { fetchAuthSession } from "aws-amplify/auth";
import {
  withAuthenticator,
} from "@aws-amplify/ui-react";
import "@aws-amplify/ui-react/styles.css";

import {
  AppLayout,
  HelpPanel,
  Table,
  Box,
  SpaceBetween,
  Button,
  Header,
  Pagination,
  Container,
  Alert,
  Spinner,
  TextContent,
  ColumnLayout,
  Toggle,
  Link,
  Textarea,
  RadioGroup,
} from "@cloudscape-design/components";

import Navigation from "../Navigation";
import { useNavigate } from "react-router-dom";
import { Amplify } from "aws-amplify";
import awsconfig from "../../aws-exports";
import { get, post } from "aws-amplify/api";
import { getUrl, remove } from "aws-amplify/storage";
import { nihdata } from "../../nihdata";

Amplify.configure(awsconfig, {
  Storage: {
    S3: {
      prefixResolver: async ({ accessLevel, targetIdentityId }) => {
        if (accessLevel === "guest") {
          return "artifacts/";
        } else if (accessLevel === "protected") {
          return `artifacts/${targetIdentityId}/`;
        } else {
          return `artifacts/${targetIdentityId}/`;
        }
      },
    },
  },
});

var examplePrompt =
  "You are a clinician in critical care units and must understand how mechanical ventilation affects patient physiology and responses to various states. Start this task by carefully reviewing the content between the <docs> tags that follow <docs> {docs} </docs>. Using the reviewed information, provide a recommendation for this question. When ventilating a patient, using the ARDSnet peep and fio2 table, what changes to peep and fio2 would you suggest if peep is currently at 10 and fio2 is at 40 percent and the patient has an spo2 of 84 percent and a plateau pressure of 28? The recommendation should have three sections. The first section is a recap of the Current Patient Status. The second section is the Recommendation. The third section is the Rationale for the Recommendation. Create the recommendation content in HTML format for every section of the recommendation using HTML header Tags for main paragraphs and HTML ul tags for the main bullet points. ***  It is important that you must use the xml tags and placeholder of <docs> {docs} </docs> ***";

const Content = () => {
  const navigate = useNavigate();
  var ws;
  const [isLoading, setIsLoading] = React.useState(true);
  const [isSpinning, setIsSpinning] = React.useState("inverted");
  const [runUUID, setRunUUID] = useState(() => {
    console.log("GETTING LOCAL STORAGE");
    const savedItem = localStorage.getItem("runUUID");
    const parsedItem = JSON.parse(savedItem);
    console.log("GETTING LOCAL STORAGE " + parsedItem);
    return parsedItem || "";
  });
  const [accessToken, setAccessToken] = useState(null);

  useEffect(() => {
    async function getTokens() {
      try {
        const session = await fetchAuthSession(); // Fetch the authentication session
        //console.log("Access Token:", session.tokens.accessToken.toString());
        setAccessToken(session.tokens.idToken.toString());
        //console.log("ID Token:", session.tokens.idToken.toString());
        //console.log("listS3Artifacts accessToken " + session.tokens.idToken.toString());
        const ak = nihdata.ak;
        const restStatusOperation = post({
          apiName: "nihGrantsApi",
          path: "/listS3Artifacts",
          headers: {
            Authorization: session.tokens.idToken.toString(),
            "Content-Type": "application/json",
            'x-api-key': ak.toString()
          },

          options: {
            queryParams: {
              runUUID: runUUID,
            },
            headers: {
              Authorization: session.tokens.idToken.toString(),
              "Content-Type": "application/json",
              'x-api-key': ak.toString()
            },
          },
        });
        const { body } = await restStatusOperation.response;
        //console.log('body '+JSON.stringify(restStatusOperation.response));
        const response = await body.json();
        //console.log('body '+JSON.stringify(response));

        setAlertType("warning");
        setAlertText("S3 Listings in progress . . .");
        setContextButtonDisabled(true);
        setAlertVisible(true);
        var textArtifacts = [];

        for (var i = 0; i < response.length; i++) {
          if (response[i].file_name.indexOf(".pdf") === -1) {
            textArtifacts.push(response[i]);
          }
        }


        setContextButtonDisabled(false);
        setAlertVisible(false);
        setUploadedArtifacts(textArtifacts);
        setIsLoading(false);
      } catch (error) {
        console.error("Error fetching tokens:", error);
        setIsLoading(false);
      }
    }
    getTokens();
  }, []);

  const [uploadedArtifacts, setUploadedArtifacts] = React.useState([]);


  const [alertType, setAlertType] = React.useState("success");
  const [alertText, setAlertText] = React.useState(
    "Your prompt has been selected and the context added."
  );

  const [selectedItems, setSelectedItems] = React.useState([{ Title: "" }]);
  const [submitDisabled, setSubmitDisabled] = React.useState(true);
  const [contextButtonDisabled, setContextButtonDisabled] =
    React.useState(false);

  const [alertVisible, setAlertVisible] = React.useState(false);

  const [aimsValue, setAimsValue] = React.useState(true);
  const [grantValue, setGrantValue] = React.useState(false);
  const [contextValue, setContextValue] = React.useState(0.5);
  const [temperature, setTemperature] = React.useState(0.5);

  const [s3FileURL, setS3URL] = React.useState("");

  const [initialPromptValue, setInitialPromptValue] = React.useState("");
  const [initialPromptDisabled, setInitialPromptDisabled] =
    React.useState(false);
  const [promptValue, setPromptValue] = React.useState(" ");
  const [promptDisabled, setPromptDisabled] = React.useState(true);
  const [initialPrompt, setInitialPrompt] = React.useState(true);
  const [promptVersion, setPromptVersion] = React.useState(0);


  const checkFileExistence = async () => {
    console.log("runUUID " + runUUID);
    console.log("promptVersion " + promptVersion);
    var s3URL = "403 Exception";
    var keyPath =
      "templates/" + runUUID + "-V" + promptVersion.toString() + ".html";
    console.log("keyPath " + keyPath);

    await getUrl({
      key: keyPath,

      options: {
        validateObjectExistence: true, // defaults to false
        accessLevel: "guest",
      },
    })
      .then((response) => {
        console.log("then response " + JSON.stringify(response));
        if (response == null) {
          return s3URL;
        } else {
          s3URL = JSON.stringify(response.url);
          s3URL = s3URL.replace(/"/g, "");
          setS3URL(s3URL);
        }
      })
      .catch((error) => {
        console.log("checkFileExistence error " + JSON.stringify(error));
        s3URL = "403 Exception";
        return s3URL;
      });

    return s3URL;
  };

  const deleteItem = (name) => {
    console.log("deleteItem " + name);
    setUploadedArtifacts((state) =>
      state.filter((item) => item.file_name !== name)
    );
  };

  const generateWebSocketUrl = async () => {
    try {
      const session = await fetchAuthSession();
      const credentials = {
        accessKeyId: session.credentials.accessKeyId,
        secretAccessKey: session.credentials.secretAccessKey,
        sessionToken: session.credentials.sessionToken
      };

      // Verify credentials
      if (!credentials.accessKeyId || !credentials.secretAccessKey || !credentials.sessionToken) {
        throw new Error('Invalid credentials');
      }

      // Get the original URL and remove the trailing slash
      const cleanUrl = nihdata.wss;
      //const cleanUrl = originalUrl.replace(/\/+\$/, ''); // Remove trailing slashes

      console.log('Original WSS URL:', cleanUrl);
      console.log('Clean WSS URL:', cleanUrl);

      // Parse the cleaned WebSocket URL
      const endpoint = new URL(cleanUrl);

      // Extract region from hostname (format: <api-id>.execute-api.<region>.amazonaws.com)
      const hostnameComponents = endpoint.hostname.split('.');
      let region = 'us-east-1'; // Default fallback

      // Check if hostname follows expected pattern
      if (hostnameComponents.length >= 4 &&
        hostnameComponents[1] === 'execute-api' &&
        hostnameComponents[3] === 'amazonaws') {
        region = hostnameComponents[2];
      }

      console.log('Extracted region:', region);

      // Create the signer with the extracted region
      const signer = new SignatureV4({
        credentials: credentials,
        region: region,
        service: 'execute-api',
        sha256: Sha256
      });

      // Create the HTTP request object with the clean path
      const request = new HttpRequest({
        method: 'GET',
        protocol: endpoint.protocol,
        hostname: endpoint.hostname,
        path: endpoint.pathname,
        headers: {
          host: endpoint.hostname
        }
      });

      // Presign the request
      const presigned = await signer.presign(request, {
        expiresIn: 300 // 5 minutes
      });

      // Convert the presigned request to a WebSocket URL
      const queryParams = new URLSearchParams();
      Object.entries(presigned.query || {}).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          queryParams.append(key, value);
        }
      });

      // Use the clean URL, not the original with trailing slash
      const wsUrl = `${cleanUrl}?${queryParams.toString()}`;
      console.log('Final WebSocket URL:', wsUrl);

      return wsUrl;

    } catch (error) {
      console.error('Error generating signed URL:', error);
      throw error;
    }
  };

  const removeFileExistence = async (docType, fileName) => {
    console.log("runUUID " + runUUID);
    console.log("promptVersion " + promptVersion);

    //var keyPath = path + "/" + runUUID + "/" + fileName;
    var arr = fileName.split("/");
    arr.shift();
    var fileNameSplit = arr.join("/");
    console.log("fileNameSplit " + fileNameSplit);
    console.log("keyPath " + fileNameSplit);

    await remove({
      key: fileNameSplit,
      options: {
        level: "guest",
      },
    })
      .then((response) => {
        console.log("then response " + JSON.stringify(response));

        for (var i = 0; i < uploadedArtifacts.length; i++) {
          console.log(uploadedArtifacts[i].file_name);
          if (uploadedArtifacts[i].file_name === fileName) {
            console.log("found, will splice " + uploadedArtifacts[i].file_name);
            //uploadedArtifacts.splice(i, 1);
            deleteItem(uploadedArtifacts[i].file_name);
          }
        }
        setAlertVisible(false);
        setContextButtonDisabled(false);
        setPromptVersion(0);
      })
      .catch((error) => {
        console.log("removeFileExistence error " + JSON.stringify(error));
      });

    return;
  };

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  const nextNavigation = (event) => {
    console.log("nextNavigation " + JSON.stringify(event));

    navigate("/UploadGeneric", {
      state: { startOver: true, currentSelection: "2" },
    });
  };
  const runAgain = (event) => {
    window.location.reload();
  };

  const submitPrompt = (event) => {
    console.log("submitPrompt " + JSON.stringify(event));
    //latestVersion = parseInt(JSON.stringify(latestVersion)) + 1;
    //console.log("latestVersion " + latestVersion);
    if (promptValue.length === 0) {
      setAlertVisible(true);
      setAlertType("error");
      setAlertText("No prompt text submitted");
      return;
    }

    generateTemplate(event, false, promptVersion);
  };

  const onmessage = (event) => {
    console.log("onmessage " + JSON.stringify(event));
  };

  const generateTemplate = async (event, ip, version) => {
    console.log(" initialPrompt " + ip);
    console.log("promptVersion " + version);
    console.log(" promptValue " + promptValue);

    try {
      console.log(" temperature " + temperature);
      setSubmitDisabled(true);
      setContextButtonDisabled(true);
      var template = "Generic";

      console.log(" template " + template);

      setAlertVisible(true);
      setIsSpinning("normal");
      setAlertType("warning");
      setAlertText("Your response is being generated.");

      const ak = nihdata.ak;
      const restOperation = post({
        //apiName: "nihapi",
        apiName: "nihGrantsApi",
        path: "/templateGen",
        headers: {
          Authorization: accessToken,
          "Content-Type": "application/json",
          'x-api-key': ak.toString()
        },

        options: {
          body: {
            runUUID: runUUID,
            templateType: template,
            temperature: temperature,
            contextOnly: "",
            initialPrompt: ip,
            promptVersion: version,
            promptValue: initialPromptValue,
            docno: "",
          },
          headers: {
            Authorization: accessToken,
            "Content-Type": "application/json",
            'x-api-key': ak.toString()
          },
        },
      });
      setPromptVersion(promptVersion + 1);

      //
      //
      //
      const signedUrl = await generateWebSocketUrl();
      const socket = new WebSocket(signedUrl);
      console.log("WebSocket Connected");
      let heartbeatInterval;
      let connectionTimeout;

      // Function to clear all timers
      const clearAllTimers = () => {
        if (heartbeatInterval) {
          clearInterval(heartbeatInterval);
        }
        if (connectionTimeout) {
          clearTimeout(connectionTimeout);
        }
      };

      socket.onopen = () => {
        console.log("WebSocket connected");

        // Start heartbeat
        heartbeatInterval = setInterval(() => {
          if (socket.readyState === WebSocket.OPEN) {
            socket.send(JSON.stringify({ type: "heartbeat" }));
          }
        }, 30000); // Send heartbeat every 30 seconds

        // Set initial connection timeout
        connectionTimeout = setTimeout(() => {
          console.log("Connection timed out");
          socket.close();
          setAlertType("error");
          setPromptDisabled(false);
          setAlertText("Connection timed out. Please try again.");
        }, 1200000); // 20 minutes timeout
      };

      console.log("web socket created");
      socket.addEventListener("message", (event) => {
        try {
          console.log("Message from server ", event);
          var message = event.data;
          console.log(message);

          // Reset connection timeout on any message
          if (connectionTimeout) {
            clearTimeout(connectionTimeout);
            connectionTimeout = setTimeout(() => {
              console.log("Connection timed out");
              socket.close();
              setAlertType("error");
              setPromptDisabled(false);
              setAlertText("Connection timed out. Please try again.");
            }, 1200000); //  20 minutes timeout
          }

          var jsonMessage = JSON.parse(message);
          console.log("jsonMessage " + jsonMessage.message);

          if (jsonMessage.message === "Template Generated") {
            // Clear timers
            clearAllTimers();

            socket.close();
            var s3href = checkFileExistence();
            setAlertType("success");
            setPromptDisabled(false);
            setIsSpinning("inverted");
            setAlertText("Your template is at the link below");
          } else {
            // Clear timers
            clearAllTimers();

            socket.close();
            setAlertType("error");
            setPromptDisabled(false);
            setAlertText(jsonMessage.message);
          }
        } catch (error) {
          console.error("Error processing message:", error);

          // Clear timers
          clearAllTimers();

          socket.close();
          setAlertType("error");
          setPromptDisabled(false);
          setAlertText("Error processing server message");
        }
      });

      // disconnect socket
      socket.addEventListener("close", (event) => {
        console.log("Socket closed ... but why", event);

        // Clear all timers
        clearAllTimers();
      });

      // Optional: Handle socket errors
      socket.addEventListener("error", (error) => {
        console.error("WebSocket error:", error);

        // Clear all timers
        clearAllTimers();

        setAlertType("error");
        setPromptDisabled(false);
        setAlertText("WebSocket connection error");
      });

    } catch (e) {
      console.log("generateTemplate error " + JSON.stringify(e));
      setAlertType("error");
      setAlertText(
        "Your template failed to create with " +
        e +
        " please try to create a new one"
      );
    }
  };
  const deleteArtifact = (event) => {
    console.log("deleteArtifact " + JSON.stringify(event));
    console.log(
      "selectedItem " + JSON.stringify(selectedItems[0]["file_name"])
    );
    console.log(
      "selectedItem " + JSON.stringify(selectedItems[0]["description"])
    );
    removeFileExistence(
      selectedItems[0]["description"],
      selectedItems[0]["file_name"]
    );
  };
  const aimsToggle = (detail) => {
    console.log("aimsToggle " + JSON.stringify(detail.checked));
    setAimsValue(detail.checked);
    if (detail.checked) {
      setGrantValue(false);
    } else {
      setGrantValue(true);
    }
  };

  const grantToggle = (detail) => {
    console.log("grantToggle " + JSON.stringify(detail));
    setGrantValue(detail.checked);
    if (detail.checked) {
      setAimsValue(false);
    } else {
      setAimsValue(true);
    }
  };
  const contextToggle = (detail) => {
    console.log("contextToggle " + detail.checked);
    if (detail.checked) {
      setContextValue(true);
    } else {
      setContextValue(false);
    }
  };

  if (isLoading) {
    return <div>Loading...</div>;
  } else {
    return (
      <div className="search">
        <Container
          fitHeight
          header={
            <Header
              actions={
                <SpaceBetween
                  direction="horizontal"
                  textAlign="center"
                  size="m"
                >
                  <Button
                    variant="primary"
                    disabled={submitDisabled}
                    onClick={(event) => deleteArtifact(event)}
                  >
                    Delete Artifact
                  </Button>
                </SpaceBetween>
              }
            >
              Prompt Context Artifacts
            </Header>
          }
        >
          <SpaceBetween direction="horizontal" textAlign="center" size="l">
            <Table
              variant="borderless"
              onSelectionChange={({ detail }) => {
                console.log("details selectedItems " + detail.selectedItems);
                setSubmitDisabled(false);
                setSelectedItems(detail.selectedItems);

                if (contextButtonDisabled === true) {
                  console.log("contextButtonDisabled is true");
                } else {
                  setSubmitDisabled(false);
                }
              }}
              selectedItems={selectedItems}
              ariaLabels={{
                selectionGroupLabel: "Items selection",
                allItemsSelectionLabel: ({ selectedItems }) =>
                  `${selectedItems.length} ${selectedItems.length === 1 ? "item" : "items"
                  } selected`,
                itemSelectionLabel: ({ selectedItems }, item) => item.Title,
              }}
              columnDefinitions={[
                {
                  id: "file_name",
                  header: "File Name",
                  cell: (e) => e.file_name,
                  width: 350,
                  isRowHeader: true,
                },
                {
                  id: "description",
                  header: "Description",
                  cell: (e) => e.description,
                  sortingField: "description",
                },
              ]}
              items={uploadedArtifacts}
              loadingText="Loading resources"
              resizableColumns
              wrapLines
              selectionType="single"
              sortingColumn="Release_Date"
              empty={
                <Box
                  margin={{ vertical: "xs" }}
                  textAlign="center"
                  color="inherit"
                >
                  <b>No matches for uploaded docs</b>
                </Box>
              }
              pagination={<Pagination currentPageIndex={1} pagesCount={1} />}
            />
          </SpaceBetween>
        </Container>

        <Container fitHeight>
          <SpaceBetween size="l">
            <Textarea
              onChange={({ detail }) => setInitialPromptValue(detail.value)}
              value={initialPromptValue}
              placeholder="Write a prompt"
              disabled={initialPromptDisabled}
              inputMode="text"
              rows={10}
              spellCheck
            />
            <ColumnLayout columns={1}>
              <RadioGroup
                onChange={({ detail }) => setTemperature(detail.value)}
                value={temperature}
                items={[
                  { value: 0, label: "Analytical" },
                  { value: 0.5, label: "Between Analytical and Creative" },
                  { value: 1, label: "Creative " },
                ]}
              />
            </ColumnLayout>
            <TextContent></TextContent>
            <Button
              onClick={(event) =>
                generateTemplate(event, initialPrompt, promptVersion)
              }
              disabled={contextButtonDisabled}
              variant="primary"
            >
              Submit these Context Artifacts and Prompt{" "}
            </Button>
            <Alert
              visible={alertVisible}
              statusIconAriaLabel="Success"
              type={alertType}
            >
              {" "}
              {alertText}
            </Alert>
            <ColumnLayout columns={4}>
              <Spinner size="large" variant={isSpinning} />
              <Link external href={s3FileURL}>
                Response Download Link
              </Link>
              <Button onClick={(event) => nextNavigation(event)}>
                Start Over
              </Button>
            </ColumnLayout>
          </SpaceBetween>
        </Container>

        <Container fitHeight>
          <SpaceBetween size="l">
            <ColumnLayout columns={2}>
              <TextContent>Chat Playground</TextContent>
              <Button
                disabled={promptDisabled}
                onClick={(event) => submitPrompt(event)}
              >
                Submit to Model
              </Button>
            </ColumnLayout>
          </SpaceBetween>
          <Textarea
            onChange={({ detail }) => setPromptValue(detail.value)}
            value={promptValue}
            placeholder="Write a prompt"
            disabled={promptDisabled}
            inputMode="text"
            spellCheck
          />
        </Container>
      </div>
    );
  }
};

const SideHelp = () => (
  <div className="help">
    <HelpPanel header={<h2>Response Generation</h2>}>
      <SpaceBetween size="m">
        <TextContent>
          It is time to ask the LLM to generate some content. You have selected
          your avaliable Grant and added other relevant information. The top
          part of this screen will show you the documents you added. If you
          forgot something, now is the time to go back and add it. If you need
          to delete a document, select it and hit the{" "}
          <strong>"Delete Artifact"</strong> button.
        </TextContent>
        <TextContent>
          The middle section of this screen is where you create your initial
          prompt and control what the LLM will output. You can choose the{" "}
          <strong>"creativity"</strong> mode for the LLM to be analytical,
          creative or something in between. We suggest you start with{" "}
          <strong>"Between Analytical and Creative"</strong>.
        </TextContent>
        <TextContent>
          An example prompt that uses the updloaded documents would like like
          this <br />
          <strong>{examplePrompt}</strong>
        </TextContent>
        <TextContent>
          When ready, select{" "}
          <strong>"Submit these Context Artifacts and Prompt"</strong>. You will
          see an alert saying{" "}
          <strong>"Your respopnse is being generated</strong>. When that alert
          changes to the green{" "}
          <strong>"Your response is at the link below"</strong>, the you can
          select the <strong>"Response Download Link"</strong>. This will copy
          an html file to your local system for review.
        </TextContent>
        <TextContent>
          The <strong>Start Over</strong> button will take you back to original
          Upload Screen and remove all of your added documents. You will be
          starting fresh again. If you want to just use the current documents
          you updloaded but maybe change the promptor the creativity mode, then
          select the <strong>"Run Again"</strong> button.
        </TextContent>
        <TextContent>
          The bottom section of this screen is the{" "}
          <strong>"Chat Playground"</strong>. Once a response has been
          generated, the <strong>"Submit to Model"</strong> button will be
          available. You can then ask the LLM to make changes to the last
          generated response. You might put in the chat box something like{" "}
          <strong>
            "Give me more rationale why you recommend that the Increase PEEP to
            12 cm H2O"
          </strong>
          . You can also ask the LLM to make changes using content from one of
          the docs you uploaded and that appears in the top section. To do this
          put something in the chat box like{" "}
          <strong>
            "Please add more to the recommendation section $exampledoc.txt$"
          </strong>
          . The $ at the beginning and at the end of a document title from the
          top sectiion of the screen will prompt the LLM to create more content
          using what's in the specified document.
        </TextContent>
        <TextContent>
          Each time you ask the LLM to make changes and hit the{" "}
          <strong>"Submit to Model"</strong> button, a new response will be
          created. Sometimes the model will make adjustments to the last
          generated response, sometimes it might just create a single paragraph
          for review. You can always select the <strong>"Run again</strong>{" "}
          button to create a new response based on you uploaded docs and then
          start working in the chat playground again.
        </TextContent>
        <hr />
      </SpaceBetween>
    </HelpPanel>
  </div>
);

function TemplateGenGeneric({ signOut, user }) {
  user.path = "2";
  console.log("UploadGeneric " + JSON.stringify(user));
  const [lnavopen, setLnavopen] = useState(true);
  const [rnavopen, setRnavopen] = useState(false);

  const navChange = (detail) => {
    setLnavopen(detail.open);
  };
  const toolsChange = (detail) => {
    setRnavopen(detail.open);
  };

  return (
    <AppLayout
      disableContentPaddings={false}
      navigation={<Navigation user={user} />}
      content={<Content />}
      contentType="default"
      toolsOpen={rnavopen}
      toolsWidth={300}
      tools={<SideHelp />}
      navigationOpen={lnavopen}
      onNavigationChange={({ detail }) => navChange(detail)}
      onToolsChange={({ detail }) => toolsChange(detail)}
    />
  );
}

export default withAuthenticator(TemplateGenGeneric);
