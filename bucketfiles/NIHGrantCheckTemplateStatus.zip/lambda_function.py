import json
import os
import boto3
from typing import Dict, Any
from aws_lambda_powertools import Logger, logging
from aws_lambda_powertools.utilities.typing import LambdaContext

logger = Logger()
logger = Logger(level="INFO")
dynamodb = boto3.resource("dynamodb")


# query an item from dynamodb table
def query_item(table_name: str, key_name: str, key_value: str) -> Dict:
    if not table_name:
        raise ValueError("Table name cannot be empty")

    if not key_name:
        raise ValueError("Key name cannot be empty")

    if not key_value:
        raise ValueError("Key value cannot be empty")
    logger.info(f"query_item table_name {table_name}" )
    logger.info(f"query_item key_name {key_name}")
    logger.info(f"query_item key_value {key_value}" )
    try:
        table = dynamodb.Table(table_name)
        
        response = table.get_item(
          Key={
            key_name: key_value
          }
        )
        if 'Item' in response:
          logger.info(f"Item with {key_name}={key_value} exists in the table.")
          logger.info(f"response {response['Item']['result']}")
          
          return {"result": str(response['Item']['result'])}
        else:
          logger.info(f"Item with {key_name}={key_value} does not exist in the table.")
          response = {"result": "NotFound"}
          return response
    except Exception as e:
        logger.error(f"query_item exception {e}")
        raise e


@logger.inject_lambda_context
def lambda_handler(event, context):
    try:
        logger.info(f"Received event: json.dumps({event}, indent=2)")

        query_string_parameters = event.get("queryStringParameters")
        if not query_string_parameters:
            raise ValueError("query_string_parameters is empty")
        run_uuid = query_string_parameters["runUUID"]
        if not run_uuid:
            raise ValueError("run_uuid is empty")
        logger.info(f"run_uuid {run_uuid}")

        
        response = query_item("nih-grants-table", "id", run_uuid)
        logger.info(f"query response {response}")
        res = {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Credentials": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "*",
            },
            "body": json.dumps(response),
        }

        logger.info(f"response success in handler {res}")

        return res

    except Exception as e:
        logger.info(f"Exception raised str({e})")

        res = {
            "statusCode": 202,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Credentials": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "*",
                "X-Amz-Function-Error": str(e),
            },
            "body": json.dumps({"result": "Exception " + str(e)}),
        }
        logger.info(f"response *** Exception *** in handler {res}")
        return res
