# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

"""
Purpose
An AWS lambda function that analyzes documents with Amazon Textract.
"""
import json
import boto3
import os



from botocore.exceptions import ClientError
from textractcaller.t_call import call_textract, OutputConfig, NotificationChannel,Textract_Features
from trp.trp2 import TDocument, TDocumentSchema
from trp.t_pipeline import order_blocks_by_geo
from textractprettyprinter.t_pretty_print import Pretty_Print_Table_Format, Textract_Pretty_Print, get_string
from textractprettyprinter.t_pretty_print import get_text_from_layout_json

import trp
import json
import urllib

# Set up logging.
from aws_lambda_powertools import Logger, logging
from aws_lambda_powertools.utilities.typing import LambdaContext

logger = Logger()
logger = Logger(level="INFO")

# Get the boto3 client.
textract_client = boto3.client("textract")
#
S3_OUTPUT_BUCKET = os.environ.get("S3_OUTPUT_BUCKET")
SNS_TOPIC_ARN = os.environ.get("SNS_TOPIC_ARN")
ROLE_ARN = os.environ.get("ROLE_ARN")
WS_DDB_TABLE = os.environ.get("WS_DDB_TABLE")
WS_ENDPOINT = os.environ.get("WS_ENDPOINT")


def publish_to_ws_clients(message):
    """
    Publishes the given text to the specified WebSocket connections.

    Args:
        text (str): The text to be published.
        connectionIds (list): A list of WebSocket connection IDs.

    Returns:
        None
    """
    
    try:
        logger.info("Publishing to WebSocket clients")
        logger.info(f"WS_DDB_TABLE {WS_DDB_TABLE}")
        logger.info(f"WS_ENDPOINT {WS_ENDPOINT}")

        table_name = WS_DDB_TABLE
        
        ddb_client = boto3.client("dynamodb")
        api_client = boto3.client('apigatewaymanagementapi', endpoint_url=WS_ENDPOINT)
        logger.info(f"message {message}")
        logger.info(f'WS_ENDPOINT {WS_ENDPOINT}')
            
        
        connections = ddb_client.scan(
                TableName= table_name,
                Select='ALL_ATTRIBUTES' # This will select All Attributes and return         
            )
        items =  connections['Items']
        logger.info(len(items))
        for item in items:
            logger.info(item['connection_id']['S'])
            clientid = item['connection_id']['S']
            logger.info(f'clientid {clientid}')
           
            response = api_client.post_to_connection(
                ConnectionId=clientid,
                Data=json.dumps({"action" : "onMessage" , "message" : message})
            )
            logger.info(response)
            
        return {
            'statusCode': 200,
            'body': json.dumps('{"response": "success"}')
        }
      
    except Exception as e:
        logger.info(f"Exception raised str({e})")
        raise e
        

def process_s3_event(event):
    """
    Processes an S3 event triggered when a new PDF file is uploaded to the S3 bucket.

    Args:
        event (dict): The event data from the S3 trigger.

    Returns:
        None
    """

    try:
        # Parse the JSON event
        #event_data = json.loads(event)
        event_data = event

        # Extract the object key from the event
        object_key = event_data[0]['s3']['object']['key']
        s3_decoded_key = urllib.parse.unquote_plus(object_key)

        # Split the object key to get the components
        key_parts = object_key.split('/')

        # Check if the object key has a .pdf extension
        if object_key.endswith('.pdf'):
            # Split the file name to get the base name without extension
            file_name = key_parts[-1]
            base_name = file_name.split('.pdf')[0]
            upload_dir = key_parts[-3]

            # Get the unique identifier from the path
            unique_id = key_parts[-2]

            return True, base_name, unique_id, s3_decoded_key, upload_dir
        else:
            return False, object_key, None, s3_decoded_key, upload_dir

    except Exception as e:
        logger.info(f"Exception raised str({e})")
        raise e
    
def lambda_handler(event, context):
    """
    Lambda handler function
    param: event: The event object for the Lambda function.
    param: context: The context object for the lambda function.
    return: The list of Block objects recognized in the document
    passed in the event object.
    """

    try:
        records = event["Records"]
        logger.info(f"records {records}")
        response = 'Document Not PDF'

        is_pdf, base_name, unique_id, s3_decoded_key,upload_dir  = process_s3_event(records)

        if is_pdf:
            print(f"The object key has a .pdf extension. Base name: {base_name}, Unique ID: {unique_id}")
            # call to textract
            pdf_bucket = f"s3://{S3_OUTPUT_BUCKET}/{s3_decoded_key}"
            j = call_textract(input_document=pdf_bucket, features=[Textract_Features.LAYOUT, Textract_Features.TABLES], )
            # get Layout from textract
            #logger.info(f"j {j}")
            layout = get_text_from_layout_json(textract_json=j)
            pages = ""
            for element in layout:

                full_text = layout[element]
                pages+=full_text+"\n"

            #logger.info(f"pages {pages}")
            logger.info(f"S3_OUTPUT_BUCKET {S3_OUTPUT_BUCKET}")
            logger.info(f"file_name {base_name}")
            logger.info(f"run_uuid {unique_id}")
            logger.info(f"S3 path artifacts/{upload_dir}/{unique_id}/{base_name}.txt") 
            
            # upload pages to S3 bucket
            s3 = boto3.resource('s3')   
            object = s3.Object(S3_OUTPUT_BUCKET, f'artifacts/{upload_dir}/{unique_id}/{base_name}.txt')
            object.put(Body=pages)
            logger.info(f"text file uploaded")

        
            response = "Document Converted"
            ws_response = publish_to_ws_clients("PDF Converted")
            logger.info(ws_response)
            

        else:
            response = "Document Not PDF"

        

        lambda_response = {"statusCode": 200, "body": json.dumps(response)}
        return (lambda_response)

    except ClientError as err:
        logger.info(f"ClientError with {s3_decoded_key}")
        error_message = "Couldn't analyze image. " + err.response["Error"]["Message"]

        lambda_response = {
            "statusCode": 202,
            "body": {
                "Error": err.response["Error"]["Code"],
                "ErrorMessage": error_message,
            },
        }
        logger.error(
            "Error function %s: %s", context.invoked_function_arn, error_message
        )
        return lambda_response

    except ValueError as val_error:
        lambda_response = {
            "statusCode": 202,
            "body": {"Error": "ValueError", "ErrorMessage": format(val_error)},
        }
        logger.error(
            "Error function %s: %s", context.invoked_function_arn, format(val_error)
        )

        return lambda_response
