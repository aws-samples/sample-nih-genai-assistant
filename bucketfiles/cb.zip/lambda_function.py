import json
import os
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
from pprint import pprint
from datetime import datetime
import typing
from typing import Dict, Tuple, Any
from aws_lambda_powertools import Logger
from aws_lambda_powertools.utilities.typing import LambdaContext
from decimal import Decimal
import time
import random

bedrock_runtime = boto3.client('bedrock-runtime')

s3 = boto3.resource("s3")
S3_OUTPUT_BUCKET = os.environ.get("S3_OUTPUT_BUCKET")
 #
REGION = os.environ.get("REGION")
MODEL_REGION = os.environ.get("MODEL_REGION")
MODEL_ID = os.environ.get("MODEL_ID")
MODEL_OUTOUT_TOKENS = int(os.environ.get("MODEL_OUTOUT_TOKENS"))
WS_ENDPOINT = os.environ.get("WS_ENDPOINT")
DDB_TABLE = os.environ.get("DDB_TABLE")
WS_DDB_TABLE = os.environ.get("WS_DDB_TABLE")

# Get environment variables
dynamodb = boto3.resource("dynamodb", region_name=REGION)
# TODO make this env var for lambda
table = dynamodb.Table(DDB_TABLE)
# set read timeout for boto3
config = Config(read_timeout=20000)
 # create bedrock client
boto3_bedrock = boto3.client(
    service_name="bedrock-runtime", region_name=MODEL_REGION, config=config)
logger = Logger(level="INFO")


def publish_to_ws_clients(message):
    """
    Publishes the given text to the specified WebSocket connections.

    Args:
        text (str): The text to be published.
        connectionIds (list): A list of WebSocket connection IDs.

    Returns:
        None
    """

    try:
        logger.info("Publishing to WebSocket clients")
        logger.info(f"WS_DDB_TABLE {WS_DDB_TABLE}")
        logger.info(f"WS_ENDPOINT {WS_ENDPOINT}")

        table_name = WS_DDB_TABLE

        ddb_client = boto3.client("dynamodb")
        api_client = boto3.client(
            'apigatewaymanagementapi', endpoint_url=WS_ENDPOINT)
        logger.info(f"message {message}")
        logger.info(f'WS_ENDPOINT {WS_ENDPOINT}')

        connections = ddb_client.scan(
                TableName=table_name,
                Select='ALL_ATTRIBUTES'  # This will select All Attributes and return
            )
        items = connections['Items']
        logger.info(len(items))
        for item in items:
            logger.info(item['connection_id']['S'])
            clientid = item['connection_id']['S']
            logger.info(f'clientid {clientid}')

            response = api_client.post_to_connection(
                ConnectionId=clientid,
                Data=json.dumps({"action": "onMessage", "message": message})
            )
            logger.info(response)

        return {
            'statusCode': 200,
            'body': json.dumps('{"response": "success"}')
        }

    except Exception as e:
        logger.info(f"Exception raised str({e})")
        raise e


def decimal_serializer(obj):
    if isinstance(obj, Decimal):
        return str(obj)
    raise TypeError("Type not serializable")


def query_item(table_name: str, key_name: str, key_value: str) -> Dict:
    if not table_name:
        raise ValueError("Table name cannot be empty")

    if not key_name:
        raise ValueError("Key name cannot be empty")

    if not key_value:
        raise ValueError("Key value cannot be empty")
    logger.info(f"query_item table_name {table_name}")
    logger.info(f"query_item key_name {key_name}")
    logger.info(f"query_item key_value {key_value}")
    try:
        table = dynamodb.Table(table_name)

        response = table.get_item(
          Key={
            key_name: key_value
          }
        )
        if 'Item' in response:
          logger.info(f"Item with {key_name}={key_value} exists in the table.")
          logger.info(f"response {response['Item']}")

          return {"result": response['Item']}
        else:
          logger.info(
              f"Item with {key_name}={key_value} does not exist in the table.")
          response = {"result": "NotFound"}
          return response
    except Exception as e:
        logger.error(f"query_item exception {e}")
        raise e


def get_all_json_objects(bucket: str, prefix: str) -> str:
    """
    Get contents of all S3 objects matching a prefix.

    Args:
      bucket: Name of S3 bucket
      prefix: Key prefix to filter objects

    Returns:
      JSON array of object key and object body
    """

    if not bucket:
        raise ValueError("Bucket is required")

    if not prefix:
        raise ValueError("Prefix is required")

    # Get all objects in folder
    objects = []
    nih_bucket = s3.Bucket(bucket)
    for obj in nih_bucket.objects.all():

        if prefix in obj.key:

            try:
                logger.info(f"for loop obj.key {obj.key}")
                if '.pdf' in obj.key:
                   continue

                body = obj.get()["Body"].read().decode("utf-8")
                objects.append({"key": obj.key, "body": body})
            except ClientError as e:
                logger.error(str(e))
                logger.info(
                    "Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.".format(
                        obj.key, bucket
                    )
                )
                raise e

    return json.dumps(objects)


def get_all_objects(bucket: str, prefix: str, count: int) -> str:
    """
    Get contents of all S3 objects matching a prefix.

    Args:
      bucket: Name of S3 bucket
      prefix: Key prefix to filter objects

    Returns:
      Concatenated contents as a string or error dict
    """

    if not bucket:
        raise ValueError("Bucket is required")

    if not prefix:
        raise ValueError("Prefix is required")

    if not count:
        raise ValueError("word_count is required")

    wc = count
    logger.info(f"wc {wc}")

    logger.info(f"bucket {bucket}")
    logger.info(f"prefix {prefix}")

    # Get all objects in folder
    text = None
    bodies = []
    nih_bucket = s3.Bucket(bucket)
    for obj in nih_bucket.objects.all():
        try:

            if prefix in obj.key:
                logger.info(f"for loop obj.key {obj.key}")
                if '.pdf' in obj.key:
                   continue

                body = obj.get()["Body"].read().decode("utf-8")

                bodies.append("<Context>"+body+"</Context>")
                # bodies.append(body)
                logger.info(f"obj.key {obj.key}")
                wc = wc + word_count(str(body), str(obj.key))

        except ClientError as e:
            logger.error(str(e))
            logger.info(
                "Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.".format(
                    obj.key, bucket
                )
            )
            raise e
    return "\n".join(bodies)


def upload_template(template: str, key: str) -> str:
    """Upload a template to S3

    Args:
      template: Template content
      key: S3 object key
    """
    if not template:
        raise ValueError("Template is required")

    if not key:
        raise ValueError("Key is required")

    try:

        logger.info(f"Uploading template to s3: {S3_OUTPUT_BUCKET}/{key}")

        s3.Bucket(S3_OUTPUT_BUCKET).put_object(Key=key, Body=template)

        return {"message": "Template uploaded successfully"}

    except Exception as e:
        logger.error(str(e))
        logger.info("Error putting object {} to bucket ".format(key))
        raise e


def process_event(event: Dict[str, Any]) -> Dict[str, Any]:
    """
        Process the event payload

        Args:
            event: The event data
    """
    try:
        event_variables = {
            "run_uuid": "",
            "template_type": "",
            "temperature": "",
            "context_only": "",
            "initial_prompt": "",
            "prompt_version": "",
            "prompt_value": "",

        }

        logger.info("START: ")
        logger.info(f"Received event: json.dumps({event}, indent=2)")

        records = event["Records"]
        logger.info(f"records {records}")
        b = records[0]["body"]
        c = json.loads(b)

        event_variables["run_uuid"] = c["runUUID"]
        event_variables["template_type"] = c["templateType"]
        event_variables["temperature"] = c["temperature"]
        event_variables["context_only"] = c["contextOnly"]
        event_variables["initial_prompt"] = c["initialPrompt"]
        event_variables["prompt_version"] = c["promptVersion"]
        event_variables["prompt_value"] = c["promptValue"]

        logger.info(f"run_uuid {event_variables["run_uuid"]}")
        logger.info(f"template_type {event_variables["template_type"]}")
        logger.info(f"temperature {event_variables["temperature"]}")
        logger.info(f"context_only {event_variables["context_only"]}")
        logger.info(f"initial_prompt {event_variables["initial_prompt"]}")
        logger.info(f"prompt_version {event_variables["prompt_version"]}")
        logger.info(f"prompt_value {event_variables["prompt_value"]}")

        return event_variables

    except Exception as e:
        logger.error(str(e))
        logger.info(
                "Error processing event object"
        )
        raise e


def word_count(str, doc):

    try:
        if not doc:
            doc = "unknown"

        count_of_words = len(str.split())
        logger.info(f"Count of Words {count_of_words} from document {doc}")

        return count_of_words

    except Exception as e:
        logger.error(str(e))
        logger.info(
                "Error in word_count"
        )
        raise e


def replace_xml(str, mode):

    try:
        new_string = None
        if not str:
            logger.error("str is NULL")
            raise e
        if (mode == 'NIHGrant'):
            # <Budget>,<BiographicalSketch>, <Resources>, <ReferencesCited>, <Explanation>
            # <SpecificAims>,<Significance>, <Innovation>, <Approach>, <Environment> and <ReferencesCited>.
            new_string = str.replace(
                "<Budget>", "<h2>Section 2</h2><br><h2> Budget </h2><br><p>")
            new_string = new_string.replace("</Budget>", "</p> <br>")
            new_string = new_string.replace(
                "<BiographicalSketch>", "<h2> Biographical Sketch </h2><br><p>")
            new_string = new_string.replace(
                "</BiographicalSketch>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<ResourceSharing>", "<h2> ResourceSharing </h2><br><p>")
            new_string = new_string.replace(
                "</ResourceSharing>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<Resource>", "<h2> Resource </h2><br><p>")
            new_string = new_string.replace("</Resource>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<ReferencesCited>", "<h2> References Cited </h2><br><p>")
            new_string = new_string.replace(
                "</ReferencesCited>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<Explanation>", "<h2> Explanation </h2><br><p>")
            new_string = new_string.replace("</Explanation>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<SpecificAims>", "<h2>Section 1</h2><br><h2> Specific Aims </h2><br><p>")
            new_string = new_string.replace(
                "</SpecificAims>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<Significance>", "<h2> Significance </h2><br><p>")
            new_string = new_string.replace(
                "</Significance>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<Innovation>", "<h2> Innovation </h2><br><p>")
            new_string = new_string.replace("</Innovation>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<Approach>", "<h2> Approach </h2><br><p>")
            new_string = new_string.replace("</Approach>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<Environment>", "<h2> Environment </h2><br><p>")
            new_string = new_string.replace("</Environment>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<ReferencesCited>", "<h2> References Cited </h2><br><p>")
            new_string = new_string.replace(
                "</ReferencesCited>", "</p> </h2><br>")
            #

        elif (mode == 'NIHAims'):
            # <SpecificAims></Specific Aims>"}, {"type": "text", "text": "<Hypotheses></Hypotheses>"}, {"type": "text", "text": "<Experiments></Experiments>"}, {"type": "text", "text":  "<Innovation></Innovation>"}, {"type": "text", "text": "<Feasibility></Feasibility>"}, {"type": "text", "text": "<Funding></Funding>"}, {"type": "text", "text": "<Resources></Resources>"}, {"type": "text", "text": "<ReferencesCited></ReferencesCited>"}],
            new_string = str.replace(
                "<SpecificAims>", "<h2> Specific Aims </h2><br><p>")
            new_string = new_string.replace("</SpecificAims>", "</p> <br>")
            new_string = new_string.replace(
                "<Hypotheses>", "<h2> Hypotheses </h2><br><p>")
            new_string = new_string.replace("</Hypotheses>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<Experiments>", "<h2> Experiments </h2><br><p>")
            new_string = new_string.replace("</Experiments>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<Innovation>", "<h2> Innovation </h2><br><p>")
            new_string = new_string.replace("</Innovation>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<Feasibility>", "<h2> Feasibility </h2><br><p>")
            new_string = new_string.replace("</Feasibility>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<Funding>", "<h2> Funding </h2><br><p>")
            new_string = new_string.replace("</Funding>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<ReferencesCited>", "<h2> References Cited </h2><br><p>")
            new_string = new_string.replace(
                "</ReferencesCited>", "</p> </h2><br>")
            new_string = new_string.replace(
                "<Explanation>", "<h2> Explanation </h2><br><p>")
            new_string = new_string.replace("</Explanation>", "</p> </h2><br>")

        elif (mode == 'Generic'):

            # new_string = "<html><body>"
            # new_string = new_string+str
            # new_string = new_string+"</body><html>"
            new_string = str

        logger.info(f"Converted XML  {new_string} ")

        return new_string

    except Exception as e:
        logger.error(str(e))
        logger.info(
                "Error in word_count"
        )
        raise e


def generate_context(event_variables: Dict[str, Any]) -> Dict[str, Any]:
    """
        Retrieve text files from S3 and generate context for the promps

        Args:
            event_variables: Dictionary of event variables
    """
    context_documents_word_count = 1
    try:
        context_documents = {
            "nihr": "",
            "grant": "",
            "docs": "",
            "aims_bp": "",
            "grant_bp": "",
            "grant_bp_summary": "",
            "grant_budget": "",
            "grant_references": "",
            "grant_biosketches": "",

        }

        logger.info(
            f"context_documents_word_count collected {context_documents_word_count}")
        response_body_bp_summary = ""
        response_body_bp_summary = get_all_objects(
            S3_OUTPUT_BUCKET,
            "artifacts/nih-grant-submission-bp-summary/",
            context_documents_word_count
        )

        context_documents["grant_bp_summary"] = f"""
        {response_body_bp_summary}

    """

        logger.info(
            f"context_documents_word_count collected {context_documents_word_count}")
        response_body_biosketches = ""
        response_body_biosketches = get_all_objects(
            S3_OUTPUT_BUCKET,
            "artifacts/nih-grant-biosketches/",
            context_documents_word_count
        )

        context_documents["grant_biosketches"] = f"""
        {response_body_biosketches}

    """

        logger.info(
            f"context_documents_word_count collected {context_documents_word_count}")
        response_body_references = ""
        response_body_references = get_all_objects(
            S3_OUTPUT_BUCKET,
            "artifacts/nih-grant-references/",
            context_documents_word_count
        )

        context_documents["grant_references"] = f"""
        {response_body_references}

    """

        logger.info(
            f"context_documents_word_count collected {context_documents_word_count}")
        response_body_budget = ""
        response_body_budget = get_all_objects(
            S3_OUTPUT_BUCKET,
            "artifacts/nih-grant-budget/",
            context_documents_word_count
        )

        context_documents["grant_budget"] = f"""
        {response_body_budget}

    """

        logger.info(
            f"context_documents_word_count collected {context_documents_word_count}")
        response_body_nihr = ""
        response_body_nihr = get_all_objects(
            S3_OUTPUT_BUCKET,
            f"artifacts/nih-reporter/{event_variables["run_uuid"]}",
            context_documents_word_count
        )

        context_documents["nihr"] = f"""
        {response_body_nihr}

    """
        logger.info("response_body_nihr collected")
        context_documents_word_count = context_documents_word_count + \
            word_count(response_body_nihr, "NIHR context")

        response_body_grant = ""
        response_body_grant = get_all_objects(
            S3_OUTPUT_BUCKET,
            f"artifacts/grant-description/{event_variables["run_uuid"]}",
            context_documents_word_count
        )
        # response_body_grant_json = get_all_json_objects(
        #   S3_OUTPUT_BUCKET, f"artifacts/grant-description/{event_variables["run_uuid"]}"
        # )
        # logger.info(f"response_body_grant_json {response_body_grant_json}")

        context_documents["grant"] = f"""

        {response_body_grant}

    """
        logger.info("response_body_grant collected")
        context_documents_word_count = context_documents_word_count + \
            word_count(response_body_grant, "Grant Overview context")

        response_body_aims_doc = ""
        response_body_aims_doc = get_all_objects(
            S3_OUTPUT_BUCKET, f"artifacts/aims-doc/{event_variables["run_uuid"]}", context_documents_word_count
        )

        context_documents["aims-doc"] = f"""

        {response_body_aims_doc}

    """

        logger.info("response_body_aims_doc collected")
        context_documents_word_count = context_documents_word_count + \
            word_count(response_body_aims_doc, "AIMScontext")

        logger.info("template_type == AIMs")
        if event_variables["template_type"] == "AIMs":
            logger.info("gathering AIMs BP")
            response_body_aims_bp = get_all_objects(
                S3_OUTPUT_BUCKET, "artifacts/nih-aims-bp/", context_documents_word_count
            )

            context_documents["aims_bp"] = f"""

                {response_body_aims_bp}

            """
            logger.info("aims_bp collected")
            context_documents_word_count = context_documents_word_count + \
                word_count(response_body_aims_bp, "AIMS BP context")
        else:
            logger.info("gathering Grant BP")
            response_body_grant_bp = ""
            response_body_grant_bp = get_all_objects(
                S3_OUTPUT_BUCKET, "artifacts/nih-grant-submission-bp/", context_documents_word_count
            )

            context_documents["grant_bp"] = f"""

                {response_body_grant_bp}

            """
            logger.info("grant_bp collected")
            context_documents_word_count = context_documents_word_count + \
                word_count(response_body_grant_bp, "GRANT BP context")

        response_body_docs = ""
        response_body_docs = get_all_objects(
            S3_OUTPUT_BUCKET, f"artifacts/customer-uploads/{event_variables["run_uuid"]}", context_documents_word_count
        )

        logger.info(
            f"word count prior to customer docs {context_documents_word_count}")

        context_documents["docs"] = f"""

        {response_body_docs}

    """
        logger.info("response_body_docs collected")
        context_documents_word_count = context_documents_word_count + \
            word_count(response_body_docs, "Customer docs context")

        logger.info(
            f"word count AFTER to customer docs {context_documents_word_count}")

        return context_documents
    except Exception as e:
        logger.error(str(e))
        logger.info(f"Error generating context {str(e)}")
        raise e


def find_and_replace_doc_ref(body, response_body_docs_json):
    try:
        # for i in range(body.count('$')):
        doc_ref = body.find('$')
        logger.info(f"doc ref {doc_ref}")
        if doc_ref == -1:
            return body
        doc_ref_end = body.find('$', doc_ref + 1)
        logger.info(f"doc ref end {doc_ref_end}")
        if doc_ref_end == -1:
            return body
        doc_ref_str = body[doc_ref+1:doc_ref_end-1]
        logger.info(f"doc ref str {doc_ref_str}")
        key = doc_ref_str
        logger.info(f"doc string key {key}")
        data = json.loads(response_body_docs_json)
        for item in data:
            logger.info(f"item {item} VS {key}")
            if key in item["key"]:
                logger.info(f"found {key} ")
                body = item["body"]
                # logger.info(f"replaced {key} with {item['body']}")
                return body

        return body
    except Exception as e:
        logger.error(str(e))
        logger.info(f"Error creating the secondary prompt {str(e)}")
        raise e


def create_chat_prompt(event_variables: Dict[str, Any], response_body_docs_json: Any) -> str:
    """
    Creates a chat prompt for a language model based on the previous prompt and response.

    Args:
        event_variables (Dict[str, Any]): A dictionary containing event variables, including the previous prompt version and initial prompt.
        response_body_docs_json (Any): JSON data containing document references and their bodies.

    Returns:
        str: The chat prompt as a string.
    """
    try:
            # retrieve last response from S3
            previous_prompt_version = event_variables["prompt_version"] - 1

            logger.info(f"previous_prompt_version {previous_prompt_version}")
            #
            wc = 5000
            # START HERE on 08-21-2024
            response_body_previous: str = get_all_objects(
                S3_OUTPUT_BUCKET,
                "artifacts/templates/" +
                    event_variables["run_uuid"] + "-V" +
                        str(previous_prompt_version)+".html",
               wc
            )
            logger.info(
                f"previous prompt for chat to start with {response_body_previous}")

            newprompt = None
            logger.info("chat create_prompt completed")
            logger.info(event_variables["initial_prompt"])
            #
            body = event_variables["prompt_value"]
            #
            char_count = body.count('$')

            if char_count == 0:
                logger.info("No document references found")
                logger.info(event_variables["prompt_value"])
                previous_doc = response_body_previous.replace('<Context>', '')
                previous_doc = previous_doc.replace('</Context>', '')
                newprompt = f"First take time to review the HTML document here: {previous_doc}. This document is what you will update and you must maintain the current HTML format. Next update the document based on this prompt: {event_variables["prompt_value"]}"
                logger.info(newprompt)
                return newprompt

            # get documents and extract bodies
            else:

                logger.info("Document references found")
                promptstart = " ".join(
                    filter(lambda x: x[0] != '$', body.split()))
                logger.info(f"promptstart {promptstart}")

                newcontext = find_and_replace_doc_ref(
                    body, response_body_docs_json)
                logger.info(
                    f"original body {body} new body {promptstart} newcontext {newcontext}")
                previous_doc = response_body_previous.replace('<Context>', '')
                previous_doc = previous_doc.replace('</Context>', '')

                newprompt = f"First take time to review the additional context between the <ac> tags. <ac> {newcontext} </ac>. Use this additional context when the performing the task that I define in the next few sentences. Please review the HTML document here: {previous_doc}. This document is what you will update and you must maintain the current HTML format. Next update the document based on this prompt: {promptstart}."
                logger.info(newprompt)
                return newprompt

    except Exception as e:
        logger.error(str(e))
        logger.info(f"Error creating the secondary prompt {str(e)}")
        raise e


def convert_message_array(message_array):
    if not message_array or not message_array[0].get("content"):
        return []

    body = message_array[0]["content"][0].get("text")

    if not body:
        return []

    converted_array = [
        {
            "role": "user",
            "content": [
                {
                    "text": body
                }
            ]
        }
    ]

    return converted_array


def invoke_model_execution(modelId, message_array, event_variables):
    try:
        logger.info("****** INVOKING MODEL ********")
        logger.info(f"modelId {modelId}")
        logger.info(f"message_array {message_array}")
        logger.info(f"max_tokens {MODEL_OUTOUT_TOKENS}")

        logger.info(f"context_only {event_variables["context_only"]}")
        logger.info(f"temperature {event_variables["temperature"]}")
        system_prompt = None
        if event_variables["template_type"] == "AIMs":
             system_prompt = "You are a National Institute of Health (NIH) researcher focused on writing a comprehensive NIH Aims Document. Observe application guidelines strictly.Use basic English and avoid jargon. Make sure all acronyms are spelled out when used initially."

        else:
             system_prompt = "You are a National Institute of Health (NIH) researcher focused on writing a comprehensive NIH Grant Proposal. You should observe application guidelines strictly. You should give concise responses to very simple questions, but provide thorough responses to more complex and open-ended questions. Make sure you strictly follow given formatting requirements."

        base_wait = 120  # Start with 120 second
        max_wait = 1200  # Maximum wait time
        max_retries = 4
        for attempt in range(max_retries):
            try:
                if "anthropic" in modelId.lower():
                    logger.info("body for anthropic API ")
                    body = json.dumps({
                        "anthropic_version": "bedrock-2023-05-31",
                        "system": system_prompt,
                        "max_tokens": MODEL_OUTOUT_TOKENS,
                        "temperature": event_variables["temperature"],
                        "top_p": 0.999,
                        "top_k": 250,
                        "messages": message_array,
                    })
                elif "amazon" in modelId.lower() and not "titan" in modelId.lower():
                    logger.info("body for amazon API ")
                    body = json.dumps({
                        "inferenceConfig": {
                            "max_new_tokens": MODEL_OUTOUT_TOKENS
                        },
                        # "temperature": event_variables.get("temperature", 1.0),
                        # "topP": 0.9,
                        "messages": convert_message_array(message_array),
                    })
                elif "titan" in modelId.lower():
                    logger.info("body for titan API ")
                    # Convert message_array to a single string
                    input_text = " ".join(
                        [msg["content"][0]["text"] for msg in message_array]) if message_array else "default input text"
                    body = json.dumps({
                        "inputText": input_text,
                        "textGenerationConfig": {
                            "maxTokenCount": 3072,
                            "stopSequences": [],
                            "temperature": event_variables.get("temperature", 0.7),
                            "topP": 0.9
                        }
                    })

                else:
                    raise ValueError(
                        "Unsupported model_id. Only 'anthropic' and 'amazon' are supported.")
                #
                response = boto3_bedrock.invoke_model(
                        modelId=modelId,
                        contentType="application/json",
                        body=body
                )
                # Process and print the response
                logger.info("messages API   response")
                result = json.loads(response.get("body").read())
                # logger.info(result)
                print(result)

                # Extracting tokens and content based on the model type
                if "anthropic" in modelId.lower():
                    input_tokens = result["usage"]["input_tokens"]
                    output_tokens = result["usage"]["output_tokens"]
                    output_list = result.get("content", [])
                elif "amazon" in modelId.lower() and not "titan" in modelId.lower():
                    print("Checking the structure of the result for Amazon model")
                    try:
                        # Use print to log the output part of the result
                        print(result["output"])
                    except KeyError as e:
                        print(f"Error accessing output: {e}")

                    try:
                        input_tokens = result["output"]["usage"]["inputTokens"]
                    except KeyError as e:
                        print(f"Error accessing input_tokens: {e}")
                        input_tokens = 0  # Fallback in case of error

                    try:
                        output_tokens = result["output"]["usage"]["outputTokens"]
                    except KeyError as e:
                        print(f"Error accessing output_tokens: {e}")
                        output_tokens = 0  # Fallback in case of error

                    try:
                        output_list = result["output"]["message"]["content"]
                    except KeyError as e:
                        print(f"Error accessing output_list: {e}")
                        output_list = []  # Fallback in case of error
                elif "titan" in modelId.lower():
                     logger.info("Processing response for titan API")

                if "results" in result and isinstance(result["results"], list) and len(result["results"]) > 0:
                    output_tokens = result["results"][0].get("tokenCount", 0)
                    # inputTokenCount is at the top level
                    input_tokens = result.get("inputTextTokenCount", 0)
                    output_text = result["results"][0].get("outputText", "")
                    print("output_text ", output_text)
                    completionReason = result["results"][0].get(
                        "completionReason", "")
                else:
                    output_tokens = 0
                    output_text = ""
                    input_tokens = 0
                    completionReason = ""  # Default value if completionReason is not found

                print("Invocation details:")
                print(f"- The input length is {input_tokens} tokens.")
                print(f"- The output length is {output_tokens} tokens.")
                if "titan" in modelId.lower():
                    print(f"- The model returned {output_text} response:")
                else:
                    print(
                        f"- The model returned {len(output_list)} response(s):")

                doc = ""
                if "titan" in modelId.lower():
                    print("Processing response for titan API")
                    output_text = output_text
                    doc += output_text
                else:
                    print("Processing response for anthropic API")
                    for output in output_list:
                        print('output ', output)
                        # Assuming 'text' is the key for other models
                        output_text = output.get("text", "")

                        logger.info(f"Output Text: {output_text}")
                        doc += output_text

                # doc = doc.replace("\r", "").replace("\n", "")
                return doc, output_tokens
            except bedrock_runtime.exceptions.ThrottlingException:
                # Exponential backoff with jitter
                wait_time = min(
                    max_wait,
                    base_wait * (2 ** attempt) + random.uniform(0, 1)
                )

                print(f"""
                Throttling detected.
                Attempt: {attempt + 1}/{max_retries}
                Wait Time: {wait_time:.2f} seconds
                """)

                time.sleep(wait_time)

        raise Exception("Max retries exceeded")

    except Exception as e:
        logger.error(str(e))
        logger.info(f"Error invoking model {str(e)}")
        raise Exception(e)
#
def process_prompt(event_variables, context_documents, prompt_number, model_id):
    """
    Process a single prompt through the model pipeline.
    
    Args:
        event_variables (dict): Variables from the event
        context_documents (dict): Context documents for prompt creation
        prompt_number (int): The prompt number to process
        model_id (str): The ID of the model to use for inference
        
    Returns:
        str: The processed result from the model
    """
    body = create_initial_prompt(event_variables, context_documents, prompt_number)
    
    # Upload prompt template
    upload_template(
        json.dumps(body), 
        f"artifacts/prompts/{event_variables['run_uuid']}_prompt-P{prompt_number}.txt"
    )
    
    # Create message array
    message_array = [{
        "role": "user",
        "content": [{"type": "text", "text": body}]
    }]
    
    # Invoke model and process result
    doc, output_tokens = invoke_model_execution(model_id, message_array, event_variables)
    result = doc.replace("\r", "").replace("\n", "")
    
    # Upload template
    upload_template(
        json.dumps(result), 
        f"artifacts/templates/{event_variables['run_uuid']}-P{prompt_number}.html"
    )
    
    return result

def get_prompt_id(template_type: str, prompt_number: int) -> str:
    """
    Generate the DynamoDB prompt ID based on template type and prompt number
    """
    if template_type == "AIMs":
        return f"ab4cf5bf-AIMS-P{prompt_number}"
    elif template_type == "Grant":
        return f"ab4cf5bf-GRANT-P{prompt_number}"
    else:
        raise ValueError(f"Unsupported template_type: {template_type}")

def create_initial_prompt(event_variables, context_documents, prompt_number):
    # This function would replace create_initial_prompt_p1 through p5
    # Use prompt_number to determine specific logic/templates
    # Return the appropriate prompt body
    """
        create the prompt based on template_type and context_only toggle

        Args:
            event_variables: Dictionary of event variables
            context_documents: Dictionary of context documents

    """
    try:
        template_type = event_variables["template_type"]
        if template_type == "AIMs":

                logger.info(f"Creating AIMs template P{prompt_number}")
                prompt_id = get_prompt_id(template_type, prompt_number)
                response = query_item(DDB_TABLE, "id", prompt_id)            
                ddb_prompt = json.dumps(response['result']['prompt'])
                formatted_prompt = ddb_prompt.format(
                    grant=context_documents["grant"],
                    aims_doc=context_documents["aims-doc"],
                    docs=context_documents["docs"],
                    nihr=context_documents["nihr"],
                    aims_bp=context_documents["aims_bp"]
                ) 
                logger.info(f"AIMs prompt {formatted_prompt}")
                body = json.dumps(
                    {
                        "prompt": formatted_prompt
                        
                    },
                    default=decimal_serializer

                )
                              
        elif template_type == "Grant":

                logger.info(f"Creating GRANT template - PROMPT {prompt_number}")
                prompt_id = get_prompt_id(template_type, prompt_number)
                response = query_item(DDB_TABLE, "id", prompt_id)
                ddb_prompt = json.dumps(response['result']['prompt'])
                
                if prompt_number == 1:
                    print("-------------------------")
                    print("PROMPT 1 - GRANT PROPOSAL")
                    print("-------------------------")
                    formatted_prompt = ddb_prompt.format(
                        grant=context_documents["grant"],
                        grant_biosketches=context_documents["grant_biosketches"], 
                        grant_budget=context_documents["grant_budget"], 
                        aims_doc=context_documents["aims-doc"],
                        docs=context_documents["docs"],
                        nihr=context_documents["nihr"]
                    ) 
                else:
                    print("-------------------------")
                    print("PROMPT 2 - GRANT PROPOSAL")
                    print("-------------------------")
                    formatted_prompt = ddb_prompt.format(
                        grant=context_documents["grant"], 
                        grant_biosketches=context_documents["grant_biosketches"], 
                        grant_budget=context_documents["grant_budget"], 
                        aims_doc=context_documents["aims-doc"], 
                        docs=context_documents["docs"], 
                        nihr=context_documents["nihr"])

                
                logger.info(f"GRANT prompt {prompt_number}: {formatted_prompt}")
                body = json.dumps(
                    {
                        "prompt": formatted_prompt
                    },
                    default=decimal_serializer

                )

        elif template_type == "Generic":

                logger.info("Creating Generic template - PROMPT 1")
                logger.info(event_variables["prompt_value"])
                response = event_variables["prompt_value"]     
                formatted_prompt = response.format(docs=context_documents["docs"]) 
                
                logger.info(f"Generic prompt {formatted_prompt}")
                body = json.dumps(
                    {
                        "prompt": formatted_prompt
                    },
                    default=decimal_serializer
                )
                             
        return body
    
    except Exception as e:
        logger.error(str(e))
        logger.info(f"Error creating the initial prompt {str(e)}")
        raise e
    
def combine_html_documents(results: list) -> str:
    """
    Takes a list of HTML documents and combines them into a single HTML document,
    removing any preliminary comments and duplicate HTML tags.
    
    Args:
        results (list): List of HTML documents from different prompts
        
    Returns:
        str: Single combined HTML document
    """
    # Define the standard HTML header and footer
    html_header = '<!DOCTYPE html><html lang="en"><head>    <meta charset="UTF-8">    <meta name="viewport" content="width=device-width, initial-scale=1.0"></head><body>'
    html_footer = '</body></html>'
    
    filtered_docs = []
    
    for doc in results:
        if not doc:
            continue
            
        # If this is the first part, skip it if it's just a comment without HTML
        if not filtered_docs and not ('<html' in doc or '<body' in doc):
            continue
            
        # Remove html, head, body tags, etc.
        content = doc
        content = content.replace('<!DOCTYPE html>', '')
        content = content.replace('<html lang="en">', '')
        content = content.replace('</html>', '')
        content = content.replace('<head>', '')
        content = content.replace('</head>', '')
        content = content.replace('<meta charset="UTF-8">', '')
        content = content.replace('<meta name="viewport" content="width=device-width, initial-scale=1.0">', '')
        content = content.replace('<body>', '')
        content = content.replace('</body>', '')
        
        # Add the cleaned content to our list
        content = content.strip()
        if content:
            filtered_docs.append(content)
    
    # Join all content together with newlines
    inner_content = '\n'.join(filtered_docs)
    
    # Create the final document
    final_html = f"{html_header}\n{inner_content}\n{html_footer}"
    
    return final_html
      
# Handler
@logger.inject_lambda_context
def lambda_handler(event, context):
    """
        Main entry point for the Lambda function

        Args:
            event: The event payload passed by Lambda 
            context: The Lambda context metadata

        Returns:
            The response payload
    """
    
    # Input validation
    if not event:
        raise ValueError("Event payload is required")

    output_tokens = 0
    try:
        
        # Get current date and time for model
        now = datetime.now()  # current date and time
        date_time = now.strftime("%m/%d/%Y, %H:%M:%S")
       
        # change to /tmp dir
        os.chdir("/tmp")
       
        modelId = MODEL_ID
        accept = "application/json"
        contentType = "application/json"
  
        event_variables = {
            "run_uuid": "",
            "template_type": "",
            "temperature": "",
            "context_only": "",
            "initial_prompt": "",
            "prompt_version": "",
            "prompt_value": "",
           
        }
        logger.info("1. setup completed")
        # Extract variables from event payload
        event_variables = process_event(event)
        logger.info("2. process_events completed")

        # retrieve customer docs json
        response_body_docs_json = get_all_json_objects(
            S3_OUTPUT_BUCKET, "artifacts/customer-uploads/" + event_variables["run_uuid"]
        )

        # retrieve the context documents
        context_documents = generate_context(event_variables)
        logger.info("3. generate_context completed")
        # create prompt and insert context

        doc = None
        if event_variables["initial_prompt"]:
            logger.info("4. initial prompt being created")
            
            if event_variables["template_type"] == "AIMs":
               
                results = []
                for prompt_number in range(1, 2):
                    result = process_prompt(event_variables, context_documents, prompt_number, modelId)
                    results.append(result)
                    
                # Combine all results  
                combined_result = combine_html_documents(results)
                upload_template(
                    json.dumps(combined_result),
                    f"artifacts/templates/{event_variables['run_uuid']}-V0.html"
                )
               
            elif event_variables["template_type"] == "Grant":
               
                results = []
                for prompt_number in range(1, 2):
                    result = process_prompt(event_variables, context_documents, prompt_number, modelId)
                    results.append(result)
                    
                # Combine all results
                #combined_result = "\n".join(results)
                
                combined_result = combine_html_documents(results)
                upload_template(
                    json.dumps(combined_result),
                    f"artifacts/templates/{event_variables['run_uuid']}-V0.html"
                ) 

            elif event_variables["template_type"] == "Generic":
                logger.info("Generic template being created")
                
                results = []
                
                result = process_prompt(event_variables, context_documents, 1, modelId)
                print(f'RESULT FOR GENERIC {result}')
                    
                upload_template(
                    json.dumps(result),
                    f"artifacts/templates/{event_variables['run_uuid']}-V0.html"
                )
                
        # secondary prompts from playground
        else:
            # remove from DDB
            table.delete_item(
                 Key={
                    "id": event_variables["run_uuid"],
                }
            )
            #
            logger.info("1. SECONDARY PROMPT being created")
            body = create_chat_prompt(event_variables, response_body_docs_json)
            logger.info(f"chat prompt {body}")

            #
            
            message_array = [
                       
                                {
                                        "role": "user",
                                        #"content": [{"type": "text", "text": json.dumps(body)}],
                                        "content": [{"type": "text", "text": body}],
                                },
                            
                        ]
            
            logger.info("chat_prompt template uploaded to S3")
            upload_template(
                json.dumps(message_array), "artifacts/prompts/" + event_variables["run_uuid"] + "_prompt"+"-V"+str(event_variables["prompt_version"])+".txt"
            )

            doc,output_tokens = invoke_model_execution(modelId, message_array,event_variables)

            logger.info("chat template created by bedrock - DDB being updated")
            # upload template to S3
            
            result = doc.replace("\r", "").replace("\n", "")
            upload_template(
                json.dumps(result), "artifacts/templates/" + event_variables["run_uuid"] +"-V"+str(event_variables["prompt_version"])+".html"
            )
           
            logger.info("chat template uploaded to S3")


        # update DDB 
   
        table.put_item(
            Item={
                "id": event_variables["run_uuid"],
                "datetime": date_time,
                "templateType": event_variables["template_type"],
                "temperature": str(event_variables["temperature"]),
                "output_tokens": str(output_tokens),
                "promptTemplateS3Key": "artifacts/prompts/" + event_variables["run_uuid"] + "_prompt.txt",
                "templateS3Key": "artifacts/templates/" + event_variables["run_uuid"] +"-V"+str(event_variables["prompt_version"])+ ".xml",
                "result": "Success",
            }
        )
        logger.info("END ---- DDB updated on success -  publish_to_ws_clients --- END")

        # publish to clients
        result = publish_to_ws_clients("Template Generated")
      
        return {"statusCode": 200, "body": json.dumps({"response": doc})}
     

    except Exception as e:
        logger.info(f"Bedrock Exception {str(e)}")
    
        try:
            table.put_item(
                Item={
                    "id": event_variables["run_uuid"],
                    "datetime": date_time,
                    "templateType": event_variables["template_type"],
                    "temperature": str(event_variables["temperature"]),
                    "output_tokens": str(output_tokens),
                    "promptTemplateS3Key": "artifacts/prompts/"
                    + event_variables["run_uuid"]
                    + "_prompt.txt",
                    "templateS3Key": "artifacts/templates/" + event_variables["run_uuid"] + ".xml",
                    "result": "Exception raised " + str(e) + " ",
                }
            )
            logger.info(f"DDB updated on error {event_variables["run_uuid"]}")
            result = publish_to_ws_clients(str(e))
            return {
                "statusCode": 202,
                "headers": {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Credentials": "*",
                    "Access-Control-Allow-Headers": "*",
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "*",
             
                },
                "body": json.dumps({"result": "Exception " + str(e)}),
            }
            
        except Exception as e:
            logger.info(f"Exception raised writing to DDB str({e})")
            result = publish_to_ws_clients(str(e))
            return {
                "statusCode": 202,
                "headers": {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Credentials": "*",
                    "Access-Control-Allow-Headers": "*",
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "*",
                    "X-Amz-Function-Error": str(e),
                },
                "body": json.dumps({"result": "Exception " + str(e)}),
            }
         
